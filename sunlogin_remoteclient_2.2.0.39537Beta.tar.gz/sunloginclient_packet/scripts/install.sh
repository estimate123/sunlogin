#!/bin/bash

echo "Sunlogin client for linux installer by oray.com"
echo "-------------------------------"

#change directory to script path
curpath=$(cd "$(dirname "$0")"; pwd)
cd $curpath > /dev/null

source ./common.sh

#check root
check_root
#kill all runing sunloginclient_linux
killall sunloginclient_linux


function old_version_lightdm_init_create
{
	src_str='\[SeatDefaults\]'
	dest_str='greeter-setup-script=xhost +'
	file_name='/etc/lightdm/lightdm.conf'
	tmp_file_name='/tmp/lightdm.conf.tmp'

	if [ ! -f $file_name ]; then
		echo "no $file_name file"
		return 1
	fi

	if [ $(grep "'$dest_str'" $file_name) ]; then
		echo 'already replace'
		return 0
	fi

	if [ $(grep "$src_str" $file_name) ]; then
		sed "s/$src_str/$src_str\n$dest_str/" $file_name > $tmp_file_name
		cp $tmp_file_name $file_name
		rm $tmp_file_name
		return 0
	else
		echo "has no [$src_str]"
		return 1
	fi
	return 1
}

function gdm_init_create
{
	dest_str='xhost +'
	file_name='/etc/gdm/Init/Default'

	if [ ! -f $file_name ]; then
		echo "no $file_name file"
		return 1
	fi

	result=$(grep "$dest_str" "$file_name")
	if [ ! "$result" == '' ]; then
		echo 'already replace'
		return 0
	fi

	sed "2 i$dest_str" -i $file_name

	return 0

}

if [ $os_name == 'ubuntu' ] || [ $os_name == 'centos' ] || [ $(echo $os_name |grep redhat) != "" ]; then
	echo 'check operate system OK'
else
	echoAndExit 'unknown OS it not impl'
fi
	

echo "copy bin"
mkdir $path_bin -p || echoAndExit "create bin directory failed : $path_bin"
cp ../bin/$os_bits/oray_rundaemon $path_bin/oray_rundaemon || echoAndExit 'can not copy oray_rundaemon file'
cp ../bin/$os_bits/sunloginclient_linux $path_bin || echoAndExit 'can not copy sunloginclient_linux file'
cp ../bin/$os_bits/ethtool $path_bin || echoAndExit 'can not copy ethtool file'
os_version_int=${os_version%.*}
for i in $(seq 1 10)
do
	os_version_int=${os_version_int%.*}
done


echo "copy etc"
mkdir $path_etc -p || echoAndExit "create etc directory failed : $path_etc"
cp ./watch.sh $path_etc || echoAndExit 'can not copy runsunlogin.sh file'
chmod +x $path_etc/watch.sh

echo "copy scripts"
cp start.sh $path_main/
cp common.sh $path_main/
cp stop.sh $path_main/
cp uninstall.sh $path_main/
cp install.sh $path_main/
chmod +x $path_main/*.sh

echo "copy doc"
mkdir "$path_doc"
cp  ../doc/* $path_doc/

echo "create init"
if [ $os_name == 'ubuntu' ]; then
	cp lightdm.conf /usr/share/lightdm/lightdm.conf.d/50-slscreenagrentsvr.conf > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo 'no pos /usr/share/lightdm, so modify base lightdm.conf file'
		old_version_lightdm_init_create
		if [ $? -ne 0 ]; then
			echo 'no lightdm.conf file, so use gdm'
			gdm_init_create
			if [ $? -ne 0 ]; then
				echoAndExit 'create lightdm init failed'
			fi
		fi
	fi
	if [ $os_version_int -lt 15 ]; then
		cp runsunloginclient.conf /etc/init/runsunloginclient.conf || echoAndExit 'can not copy init file runsunloginclient.conf'
	else
		cp runsunloginclient.service /etc/systemd/system/runsunloginclient.service || echoAndExit 'can not copy init file runsunloginclient.service'
		systemctl enable runsunloginclient.service
	fi

	echo "Sunlogin client installed. Enjoy!"
	cd - > /dev/null

	echo "get lightdm X Authority"
	xhost + >/dev/null 2>&1 || service lightdm restart || service gdm restart

elif  [ "$os_name" == "centos" ] || [ $(echo $os_name |grep redhat) != "" ] ; then
	gdm_init_create
	if [ $os_version_int -lt 7 ]; then
		cp init_runsunloginclient /etc/init.d/runsunloginclient || echoAndExit 'can not copy init file init_runsunloginclient'
		chmod +x /etc/init.d/runsunloginclient
		#create soft link
		for i in $(seq 0 6)
		do
			ln -s /etc/init.d/runsunloginclient /etc/rc$i.d/S99runsunloginclient > /dev/null 2>&1
		done
		/sbin/chkconfig --add runsunloginclient
		/sbin/chkconfig runsunloginclient on
	else
		cp runsunloginclient.service /etc/systemd/system/runsunloginclient.service || echoAndExit 'can not copy init file runsunloginclient.service'
		systemctl enable runsunloginclient.service
	fi

	echo "Sunlogin client installed in $path_main Enjoy!"
	cd - > /dev/null

	echo "get gdm X Authority"
	xhost + >/dev/null 2>&1 || /usr/sbin/gdm-restart
else

	echo 'unknown OS is not impl'
fi
