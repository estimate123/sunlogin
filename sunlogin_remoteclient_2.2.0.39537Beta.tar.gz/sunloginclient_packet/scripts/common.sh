
function echoAndExit
{
	echo -n 'Error:'
	echo $1
	echo 'Installation failed'
	exit 1
}

#check root
function check_root
{
	if [ $(whoami) != 'root' ]; then
		if [ "$1" == "" ]; then
			echo 'Sunlogin client needs root to complete installation'
		else
			echo "$1"
		fi
		exit 1
	fi
}

path_main='/usr/local/sunlogin'
path_bin="$path_main/bin"
path_etc="$path_main/etc"
path_doc="$path_main/doc"
path_log="$path_main/var/log"

#get operation system info
which lsb_release > /dev/null 2>&1
if [ $? -ne 0 ]; then
	echo 'lsb_release is not exist, now install it'
	yum install redhat-lsb -y
fi
which lsb_release > /dev/null 2>&1
if [ $? -ne 0 ]; then
	echo 'lsb_release is not exist, please install it first'
	exit 1
fi

os_name=$(lsb_release -i | cut -d : -f 2)
os_version='0.0'
for i in $(seq 1 10)
do
	os_desc=$(lsb_release -d)
	os_version_tmp=$(echo $os_desc | cut -d ' ' -f $i)
	if [ $(echo $os_version_tmp | awk '{print($0~/^[-]?([0-9])+([.]?([0-9])+)+$/)?"number":"string"}') == 'number' ]; then
		os_version=$os_version_tmp
		break
	fi
done
os_name=$(echo $os_name | tr [A-Z] [a-z])
os_bits=$(getconf LONG_BIT)

#echo $os_name
#echo $os_version
