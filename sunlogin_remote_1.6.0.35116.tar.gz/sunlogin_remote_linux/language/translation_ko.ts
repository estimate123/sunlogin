<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>About</name>
    <message>
        <location filename="qml/About.qml" line="9"/>
        <source>Sunlogin Remote Control </source>
        <translation>해바라기 원격제어 </translation>
    </message>
    <message>
        <location filename="qml/About.qml" line="70"/>
        <location filename="qml/About.qml" line="83"/>
        <location filename="qml/About.qml" line="89"/>
        <source>About Sunlogin Remote Control</source>
        <translation> 해바라기 원격제어에 관하여</translation>
    </message>
    <message>
        <location filename="qml/About.qml" line="91"/>
        <location filename="qml/About.qml" line="122"/>
        <source>Break through the endless imagination...</source>
        <translation>혁신, 끊임없는 상상력입니다...</translation>
    </message>
    <message>
        <source>Sunlogin Remote Control for Mac V1.0.0(9809)</source>
        <translation type="obsolete">해바라기 원격제어 for Mac V1.0.0(9809)</translation>
    </message>
</context>
<context>
    <name>AddCameraSuccessWindow</name>
    <message>
        <location filename="qml/AddCameraSuccessWindow.qml" line="63"/>
        <location filename="qml/AddCameraSuccessWindow.qml" line="82"/>
        <location filename="qml/AddCameraSuccessWindow.qml" line="88"/>
        <source>Add host/camera</source>
        <translation>호스트 / 카메라 추가</translation>
    </message>
    <message>
        <location filename="qml/AddCameraSuccessWindow.qml" line="89"/>
        <source>Connect camera</source>
        <translation></translation>
    </message>
    <message>
        <location filename="qml/AddCameraSuccessWindow.qml" line="90"/>
        <source>Continue adding</source>
        <translation>계속추가</translation>
    </message>
    <message>
        <location filename="qml/AddCameraSuccessWindow.qml" line="120"/>
        <source>Connect</source>
        <translation>연결</translation>
    </message>
    <message>
        <location filename="qml/AddCameraSuccessWindow.qml" line="137"/>
        <source>Continue</source>
        <translation>계속</translation>
    </message>
</context>
<context>
    <name>AddCameraWindowPage</name>
    <message>
        <location filename="qml/AddCameraWindowPage.qml" line="19"/>
        <location filename="qml/AddCameraWindowPage.qml" line="55"/>
        <source>Camera name:</source>
        <translation>카메라 이름 :</translation>
    </message>
    <message>
        <location filename="qml/AddCameraWindowPage.qml" line="20"/>
        <location filename="qml/AddCameraWindowPage.qml" line="68"/>
        <source>Camera description:</source>
        <translation>카메라 설명 :</translation>
    </message>
    <message>
        <location filename="qml/AddCameraWindowPage.qml" line="21"/>
        <location filename="qml/AddCameraWindowPage.qml" line="80"/>
        <source>UID:</source>
        <translation>UID :</translation>
    </message>
    <message>
        <location filename="qml/AddCameraWindowPage.qml" line="159"/>
        <source>The camera has been added by the other account</source>
        <translation>카메라가 다른 계정에 추가되었습니다, ​​당신은 다시 선택할 수 있습니다</translation>
    </message>
    <message>
        <location filename="qml/AddCameraWindowPage.qml" line="164"/>
        <source>How to reset</source>
        <translation>다시 설정하는 방법</translation>
    </message>
</context>
<context>
    <name>AddHostWindowPage</name>
    <message>
        <location filename="qml/AddHostWindowPage.qml" line="21"/>
        <location filename="qml/AddHostWindowPage.qml" line="54"/>
        <source>Host name:</source>
        <translation>호스트 명칭：</translation>
    </message>
</context>
<context>
    <name>CameraInfo</name>
    <message>
        <source>摄像头属性</source>
        <translation type="obsolete">섭상두속성</translation>
    </message>
    <message>
        <source>常规</source>
        <translation type="obsolete">인습</translation>
    </message>
    <message>
        <location filename="qml/CameraInfo.qml" line="114"/>
        <location filename="qml/CameraInfo.qml" line="119"/>
        <location filename="qml/CameraInfo.qml" line="177"/>
        <source>Camera Properties</source>
        <translation>섭상두속성</translation>
    </message>
    <message>
        <location filename="qml/CameraInfo.qml" line="273"/>
        <source>Common</source>
        <translation>일반</translation>
    </message>
    <message>
        <location filename="qml/CameraInfo.qml" line="281"/>
        <source>OK</source>
        <translation>결심</translation>
    </message>
    <message>
        <location filename="qml/CameraInfo.qml" line="296"/>
        <source>Host name cannot be empty</source>
        <translation>카메라 이름은 비워 둘 수 없습니다</translation>
    </message>
</context>
<context>
    <name>CameraInfoPanel</name>
    <message>
        <source>画质:</source>
        <translation type="obsolete">그림 성격:</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel.qml" line="65"/>
        <source>Picture quality:</source>
        <translation>그림 성격:</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel.qml" line="79"/>
        <location filename="qml/CameraInfoPanel.qml" line="105"/>
        <location filename="qml/CameraInfoPanel.qml" line="130"/>
        <location filename="qml/CameraInfoPanel.qml" line="155"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel.qml" line="93"/>
        <source>Image flip:</source>
        <translation>심상은 인계한다:</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel.qml" line="118"/>
        <source>Motion detection recording:</source>
        <translation>운동 탐지 비디오 녹화:</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel.qml" line="143"/>
        <source>Firmware version:</source>
        <translation>굳힌모 판:</translation>
    </message>
    <message>
        <source>图像翻转:</source>
        <translation type="obsolete">심상은 인계한다:</translation>
    </message>
    <message>
        <source>运动侦测录像:</source>
        <translation type="obsolete">운동 탐지 비디오 녹화:</translation>
    </message>
    <message>
        <source>固件版本:</source>
        <translation type="obsolete">굳힌모 판:</translation>
    </message>
</context>
<context>
    <name>CameraInfoPanel2</name>
    <message>
        <location filename="qml/CameraInfoPanel2.qml" line="52"/>
        <source>UID:</source>
        <translation>UID :</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel2.qml" line="65"/>
        <location filename="qml/CameraInfoPanel2.qml" line="90"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel2.qml" line="79"/>
        <source>Firmware version:</source>
        <translation>굳힌모 판:</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel2.qml" line="102"/>
        <source>Upgrade</source>
        <translation>업그레이드</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel2.qml" line="128"/>
        <source>Camera name:</source>
        <translation>카메라 이름 :</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel2.qml" line="152"/>
        <source>Camera description:</source>
        <translation>카메라 설명 :</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel2.qml" line="175"/>
        <source>Save path:</source>
        <translation>사진 / 비디오 저장 :</translation>
    </message>
    <message>
        <location filename="qml/CameraInfoPanel2.qml" line="197"/>
        <source>RunOver</source>
        <translation>검색</translation>
    </message>
</context>
<context>
    <name>CameraSetDlg</name>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600; color:#ffffff;&quot;&gt;Definition&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="76"/>
        <source>Superquality</source>
        <translation>초과 청</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="125"/>
        <source>Hightquality</source>
        <translation>고화질</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="174"/>
        <source>Lowquality</source>
        <translation>청 표</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="217"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600; color:#ffffff;&quot;&gt;contrast&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="230"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600; color:#ffffff;&quot;&gt;brilliance&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="281"/>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="297"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;TextLabel&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.ui" line="459"/>
        <source>SetBack</source>
        <translation>초기 복원</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.cpp" line="97"/>
        <source>Set Back</source>
        <translation>초기 복원</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.cpp" line="103"/>
        <source>SD</source>
        <translation>청 표</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.cpp" line="102"/>
        <source>HD</source>
        <translation>고화질</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.cpp" line="101"/>
        <source>UHD</source>
        <translation>초과 청</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.cpp" line="108"/>
        <source>Definition</source>
        <translation>정의</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.cpp" line="110"/>
        <source>Brilliance</source>
        <translation>밝기</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/camerasetdlg.cpp" line="112"/>
        <source>Contrast</source>
        <translation>대비</translation>
    </message>
</context>
<context>
    <name>CameraUpgrade</name>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="76"/>
        <source>Discover new version </source>
        <translation>새 버전보세요</translation>
    </message>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="77"/>
        <location filename="qml/CameraUpgrade.qml" line="262"/>
        <source>Upgrade</source>
        <translation>업그레이드</translation>
    </message>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="82"/>
        <source>This is the last version</source>
        <translation>최신 버전은 이미</translation>
    </message>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="48"/>
        <location filename="qml/CameraUpgrade.qml" line="83"/>
        <source>OK</source>
        <translation>결심</translation>
    </message>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="19"/>
        <source>Firmware upgrading...</source>
        <translation>펌웨어 업그레이드 ...</translation>
    </message>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="43"/>
        <source>Upgrade successfully</source>
        <translation>펌웨어 업그레이드에 성공했습니다</translation>
    </message>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="172"/>
        <location filename="qml/CameraUpgrade.qml" line="196"/>
        <source>Camera upgrade</source>
        <translation>카메라 업그레이드</translation>
    </message>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="185"/>
        <source>Quiting to upgrade...</source>
        <translation>종료 업그레이드...</translation>
    </message>
    <message>
        <location filename="qml/CameraUpgrade.qml" line="208"/>
        <source>Discover new version</source>
        <translation>새 버전보세요</translation>
    </message>
</context>
<context>
    <name>ChatTextEdit</name>
    <message>
        <location filename="../plugin/OrayChatClient/ChatTextEdit.cpp" line="139"/>
        <source>Copy</source>
        <translation>부</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/ChatTextEdit.cpp" line="140"/>
        <source>Select All</source>
        <translation>선택</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/ChatTextEdit.cpp" line="141"/>
        <source>Clear</source>
        <translation>과거 기록</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/ChatTextEdit.cpp" line="142"/>
        <source>Paste</source>
        <translation>스틱</translation>
    </message>
</context>
<context>
    <name>DirectionOperateShow</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Form</translation>
    </message>
</context>
<context>
    <name>DirectionView</name>
    <message>
        <location filename="../plugin/CameraPlayer/DirectionView.ui" line="14"/>
        <source>Form</source>
        <translation>형태</translation>
    </message>
</context>
<context>
    <name>DiscoverLanCamera</name>
    <message>
        <location filename="qml/DiscoverLanCamera.qml" line="19"/>
        <source>My camera</source>
        <translation>내 웹캠</translation>
    </message>
    <message>
        <location filename="qml/DiscoverLanCamera.qml" line="26"/>
        <source>Add camera successfully</source>
        <translation>카메라의 성공을 추가</translation>
    </message>
    <message>
        <location filename="qml/DiscoverLanCamera.qml" line="85"/>
        <location filename="qml/DiscoverLanCamera.qml" line="105"/>
        <source>Discover camera</source>
        <translation>발견 카메라</translation>
    </message>
    <message>
        <location filename="qml/DiscoverLanCamera.qml" line="118"/>
        <source>Discover camera,Add?</source>
        <translation>LAN 추가, 카메라를 발견?</translation>
    </message>
    <message>
        <location filename="qml/DiscoverLanCamera.qml" line="198"/>
        <source>Add</source>
        <translation>추가</translation>
    </message>
</context>
<context>
    <name>DlgNavigation</name>
    <message>
        <location filename="dlgnavigation.h" line="490"/>
        <location filename="dlgnavigation.h" line="563"/>
        <source>About</source>
        <translation>관하여</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="491"/>
        <source>Quit</source>
        <translation>나가기</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="492"/>
        <source>Change account</source>
        <translation>계정변경</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="494"/>
        <source>Setting</source>
        <translation>설정</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="524"/>
        <source>Common problems</source>
        <translation>자주 묻는 질문</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="525"/>
        <source>Suggestion feedback</source>
        <translation>피드백</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="514"/>
        <location filename="dlgnavigation.h" line="547"/>
        <location filename="dlgnavigation.h" line="2583"/>
        <source>Online</source>
        <translation>온라인</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="515"/>
        <location filename="dlgnavigation.h" line="552"/>
        <location filename="dlgnavigation.h" line="2584"/>
        <location filename="dlgnavigation.h" line="2597"/>
        <source>Logout</source>
        <translation>로그오프</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="557"/>
        <location filename="dlgnavigation.h" line="2585"/>
        <source>Exit</source>
        <translation>나가기</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="516"/>
        <location filename="dlgnavigation.h" line="562"/>
        <location filename="dlgnavigation.h" line="927"/>
        <location filename="dlgnavigation.h" line="2586"/>
        <source>Lock</source>
        <oldsource> Lock</oldsource>
        <translation>잠금</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="511"/>
        <source>Status</source>
        <oldsource>&amp;Status</oldsource>
        <translation>지위</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="529"/>
        <source>Help</source>
        <translation>도움</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="614"/>
        <location filename="dlgnavigation.h" line="2590"/>
        <source>Add hosts</source>
        <oldsource>Add Host</oldsource>
        <translation>데스크톱 추가</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="615"/>
        <location filename="dlgnavigation.h" line="2591"/>
        <source>Add tags</source>
        <translation>꼬리표추가</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="625"/>
        <location filename="dlgnavigation.h" line="651"/>
        <location filename="dlgnavigation.h" line="2606"/>
        <source>Select all</source>
        <translation>선택</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="626"/>
        <source>Copy</source>
        <translation>부</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="635"/>
        <source>Refresh hosts</source>
        <translation>새로 고침</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="636"/>
        <location filename="dlgnavigation.h" line="2593"/>
        <source>Remote wake up</source>
        <translation>원격부팅</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="637"/>
        <location filename="dlgnavigation.h" line="675"/>
        <location filename="dlgnavigation.h" line="2594"/>
        <source>Remote desktop</source>
        <translation>원격 데스크</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="638"/>
        <location filename="dlgnavigation.h" line="676"/>
        <location filename="dlgnavigation.h" line="2596"/>
        <source>Remote file</source>
        <translation>원격 파일</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="639"/>
        <location filename="dlgnavigation.h" line="677"/>
        <source>Remote CMD</source>
        <translation>CMD</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="640"/>
        <location filename="dlgnavigation.h" line="678"/>
        <location filename="dlgnavigation.h" line="2595"/>
        <source>Remote camera</source>
        <translation>원격캠</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="641"/>
        <source>Remote Chat</source>
        <translation>대화</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="642"/>
        <source>Logout host</source>
        <translation>로그오프</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="643"/>
        <location filename="dlgnavigation.h" line="2598"/>
        <source>Delete host</source>
        <translation>호스트 삭제</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="644"/>
        <location filename="dlgnavigation.h" line="2599"/>
        <source>Delete camera</source>
        <translation>사진기를 삭제한다</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="645"/>
        <location filename="dlgnavigation.h" line="2600"/>
        <source>Host info</source>
        <translation>호스트 속성</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="646"/>
        <location filename="dlgnavigation.h" line="2601"/>
        <source>Camera info</source>
        <translation>사진기 정보</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="647"/>
        <source>Add screen wall</source>
        <translation>스크린 검사</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="648"/>
        <location filename="dlgnavigation.h" line="2603"/>
        <source>batch execute</source>
        <translation>얼마나</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="649"/>
        <location filename="dlgnavigation.h" line="2604"/>
        <source>cancel batch execute</source>
        <translation>다중 선택 해제</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="650"/>
        <location filename="dlgnavigation.h" line="2605"/>
        <source>batch delete</source>
        <translation>지우기 선택한</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="679"/>
        <source>Remove host</source>
        <translation>移除主机</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="699"/>
        <location filename="dlgnavigation.h" line="2610"/>
        <source>Common</source>
        <translation>일반</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="700"/>
        <location filename="dlgnavigation.h" line="1297"/>
        <location filename="dlgnavigation.h" line="2611"/>
        <source>Host authorization</source>
        <translation>호스트 크레딧</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="701"/>
        <location filename="dlgnavigation.h" line="2612"/>
        <source>IP settings</source>
        <translation>IP 설정</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="702"/>
        <location filename="dlgnavigation.h" line="2613"/>
        <source>DDNS settings</source>
        <translation>DDNS 설정</translation>
    </message>
    <message>
        <source>Version update</source>
        <translation type="obsolete">업데이트</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="924"/>
        <source>Unlock</source>
        <translation>언락</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="1295"/>
        <source>Host manager</source>
        <translation>호스트 관리</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="1627"/>
        <source>Loading...</source>
        <translation>인식중…</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="1732"/>
        <location filename="dlgnavigation.h" line="1763"/>
        <source>Are you sure to delete [</source>
        <translation>호스트를 삭제하시겠습니까?</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="1732"/>
        <location filename="dlgnavigation.h" line="1763"/>
        <source>]?</source>
        <translation>까?</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="1737"/>
        <location filename="dlgnavigation.h" line="1768"/>
        <source>You have no permission to delete a shared host</source>
        <translation>호스트는 공유호스트로, 삭제할 권한 없음</translation>
    </message>
    <message>
        <location filename="dlgnavigation.cpp" line="801"/>
        <source>You have no select any host</source>
        <translation>선택하지 않은 어떤 호스트</translation>
    </message>
    <message>
        <location filename="dlgnavigation.cpp" line="807"/>
        <source>Are you sure to delete this host?</source>
        <translation>너 확실히 삭제 이 호스트?</translation>
    </message>
    <message>
        <location filename="dlgnavigation.cpp" line="835"/>
        <source>You have no permission to delete these shared host</source>
        <translation>너 없이 삭제 권한 이 공유 호스트</translation>
    </message>
    <message>
        <location filename="dlgnavigation.cpp" line="840"/>
        <source>there are some shared host,continue?</source>
        <translation>여기 일부 공유 호스트 계속?</translation>
    </message>
    <message>
        <location filename="dlgnavigation.cpp" line="847"/>
        <source>Are you sure to delete these camera?</source>
        <translation>너 정말 이 카메라 삭제하시겠습니까?</translation>
    </message>
    <message>
        <location filename="dlgnavigation.cpp" line="855"/>
        <source>Are you sure to delete these host and camera?</source>
        <translation>너 확실히 이러한 호스트 및 카메라 삭제하시겠습니까?</translation>
    </message>
    <message>
        <location filename="dlgnavigation.cpp" line="859"/>
        <location filename="dlgnavigation.h" line="1733"/>
        <location filename="dlgnavigation.h" line="1764"/>
        <location filename="dlgnavigation.h" line="1995"/>
        <source>Prompt</source>
        <translation>표시</translation>
    </message>
    <message>
        <source>can&apos;t delete online camera &apos; [</source>
        <translation type="obsolete">온라인 사진기를 &apos;삭제할 수 없습니다[</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="1995"/>
        <source>Are you sure to exit?</source>
        <translation>정말 종료하시겠습니까？</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="2092"/>
        <source>Wake up successfully, the host is online</source>
        <translation>부팅성공，호스트 이미 온라인</translation>
    </message>
    <message>
        <location filename="dlgnavigation.h" line="2254"/>
        <source>Sunlogin Control Client is offline</source>
        <translation>리모트주체 오프라인</translation>
    </message>
</context>
<context>
    <name>FileAttribute</name>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="29"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="174"/>
        <source>Type:</source>
        <translation>유형:</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="308"/>
        <source>Size:</source>
        <translation>크기:</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="442"/>
        <source>Location:</source>
        <translation>위치:</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="651"/>
        <source>Access:</source>
        <translation>액세스 시간:</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="785"/>
        <source>Modification:</source>
        <translation>개정 시간:</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="919"/>
        <source>Created:</source>
        <translation>창당 시기:</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="1049"/>
        <source>OK</source>
        <translation>확정</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.ui" line="1085"/>
        <source>Normal</source>
        <translation>일반</translation>
    </message>
    <message>
        <source>修改时间：</source>
        <translation type="obsolete">수정일 :</translation>
    </message>
    <message>
        <source>创建时间：</source>
        <translation type="obsolete">작성일 :</translation>
    </message>
    <message>
        <source>类型：</source>
        <translation type="obsolete">유형 :</translation>
    </message>
    <message>
        <source>大小：</source>
        <translation type="obsolete">크기 :</translation>
    </message>
    <message>
        <source>位置：</source>
        <translation type="obsolete">위치 :</translation>
    </message>
    <message>
        <source>访问时间：</source>
        <translation type="obsolete">액세스 시간 :</translation>
    </message>
    <message>
        <source>确定</source>
        <translation type="obsolete">결정</translation>
    </message>
    <message>
        <source>常规</source>
        <translation type="obsolete">인습</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.cpp" line="60"/>
        <location filename="../plugin/NewFileManager/fileattribute.cpp" line="116"/>
        <source>Floder</source>
        <translation>폴더</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/fileattribute.cpp" line="60"/>
        <location filename="../plugin/NewFileManager/fileattribute.cpp" line="116"/>
        <source>file</source>
        <translation>파일</translation>
    </message>
</context>
<context>
    <name>FileManagerForm</name>
    <message>
        <location filename="../plugin/NewFileManager/filemanagerform.ui" line="20"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="121"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1541"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="121"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1545"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="121"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1541"/>
        <source>Tip</source>
        <translation>신속한</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="122"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="122"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="122"/>
        <source>Please waiting...</source>
        <translation>기다려주십시오 ...</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="128"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="128"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="128"/>
        <source>Local host</source>
        <translation>로컬 호스트</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="129"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="129"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="129"/>
        <source>Remote host</source>
        <translation>원격 호스트</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="157"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="157"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="157"/>
        <source>Open</source>
        <translation>열린</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="159"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="259"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="260"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="261"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="276"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="277"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="278"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="159"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="259"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="260"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="261"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="276"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="277"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="278"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="159"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="259"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="260"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="261"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="276"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="277"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="278"/>
        <source>Transfer</source>
        <translation>전달</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="161"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="161"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="161"/>
        <source>Select all</source>
        <translation>선택</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="163"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="163"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="163"/>
        <source>Inverse</source>
        <translation>반대로 선거</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="165"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="165"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="165"/>
        <source>Copy</source>
        <translation>부</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="167"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="179"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="255"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="272"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="167"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="179"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="255"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="272"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="167"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="179"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="255"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="272"/>
        <source>Delete</source>
        <translation>삭제</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="169"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2212"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="169"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2214"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="169"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2210"/>
        <source>Attribute</source>
        <translation>재산</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="171"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="171"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="171"/>
        <source>Paste</source>
        <translation>스틱</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="173"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="253"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="270"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="173"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="253"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="270"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="173"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="253"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="270"/>
        <source>New</source>
        <translation>새로운</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="218"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="218"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="218"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="177"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="219"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1847"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1866"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1960"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1961"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="177"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="219"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1851"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1870"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1964"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1965"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="177"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="219"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1847"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1866"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1960"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1961"/>
        <source>Pause</source>
        <translation>중지</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="obsolete">제거</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="181"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="181"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="181"/>
        <source>Move up</source>
        <translation>움직임</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="183"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="183"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="183"/>
        <source>Move down</source>
        <translation>아래로</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="185"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="185"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="185"/>
        <source>Move top</source>
        <translation>상단으로 이동</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="187"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="187"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="187"/>
        <source>Move bottom</source>
        <translation>아래로 이동</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="246"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="263"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="246"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="263"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="246"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="263"/>
        <source>Back</source>
        <translation>후퇴</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="248"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="265"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="248"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="265"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="248"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="265"/>
        <source>Advance</source>
        <translation>전진</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="250"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="267"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="250"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="267"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="250"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="267"/>
        <source>Refresh</source>
        <translation>새로 고침</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="252"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="269"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="252"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="269"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="252"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="269"/>
        <source>Up</source>
        <translation>올라</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="254"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="271"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="254"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="271"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="254"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="271"/>
        <source>Rename</source>
        <translation>이름 바꾸기</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="256"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="257"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="258"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="273"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="274"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="275"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="256"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="257"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="258"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="273"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="274"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="275"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="256"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="257"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="258"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="273"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="274"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="275"/>
        <source>Select</source>
        <translation>선택</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="279"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="279"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="279"/>
        <source>Loading...</source>
        <translation>에 로그인 ...</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="403"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="622"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2487"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2550"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="405"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="626"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2487"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2550"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="405"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="624"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2483"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2546"/>
        <source>Folder</source>
        <translation>폴더</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="414"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="631"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="416"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="635"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="416"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="633"/>
        <source>File</source>
        <translation>파일</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="960"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="964"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="960"/>
        <source>Loading timed out, please refresh the list and try again</source>
        <translation>로그인 타임 아웃은, 목록을 새로 다시 로그인</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1010"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1014"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1010"/>
        <source>Speed:</source>
        <translation>속도 :</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1026"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1030"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1026"/>
        <source>Remaining time:</source>
        <translation>남은:</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1033"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1059"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1037"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1063"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1033"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1059"/>
        <source>Speed:--KB/s</source>
        <translation>속도 :--KB/s</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1035"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1061"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1039"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1065"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1035"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1061"/>
        <source>Remaining time:--</source>
        <translation>남은:--</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1066"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1070"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1066"/>
        <source>Time consuming:</source>
        <translation>시간 :</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1136"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1172"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1140"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1176"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1136"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1172"/>
        <source>Select </source>
        <translation>선택</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1136"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1172"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1140"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1176"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1136"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1172"/>
        <source> items,the file size: </source>
        <translation>파일, 파일 크기는 :</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1143"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1179"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1147"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1183"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1143"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1179"/>
        <source>Select one item,the file size: </source>
        <translation>파일 크기를 선택합니다 :</translation>
    </message>
    <message>
        <source>Resume</source>
        <translation type="obsolete">계속</translation>
    </message>
    <message>
        <source>Do you want to replace the existing?</source>
        <translation type="obsolete">파일이 이미 존재, 대체?</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1272"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1280"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1276"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1284"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1272"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1280"/>
        <source>Fail to rename file</source>
        <translation>실패한 파일의 이름을 바꿉니다</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1273"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1277"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1273"/>
        <source>Fail to rename, file  exist or maintain illeage charactor.</source>
        <translation>이름 바꾸기에 실패, 파일이 이미 존재하거나 잘못된 문자가 포함되어있을 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1276"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1280"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1276"/>
        <source>Fail to create new file</source>
        <translation>실패 폴더를 만듭니다</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1277"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1281"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1277"/>
        <source>Fail to create new file or folder.</source>
        <translation>새 폴더를 생성하지 못했습니다.</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1281"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1285"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1281"/>
        <source>file or folder&apos;s name can&apos;t be empty.</source>
        <translation>폴더 이름은 비워 둘 수 없습니다.</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1348"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1352"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1348"/>
        <source>is existed, Do you want to replace the existing?</source>
        <translation>문서 몸은 대체 존재?</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1349"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1353"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1349"/>
        <source>Confirm the file cover</source>
        <translation>파일 바꾸기 확인</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1353"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1358"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1357"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1362"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1353"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1358"/>
        <source>Transmission is not finished during last session, attempt to resume?</source>
        <translation>이 파일은 다시 시작하려는 경우 마지막에는 전송이 완료 되었나요?</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1354"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1359"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1358"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1363"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1354"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1359"/>
        <source>Confirm the file transmission</source>
        <translation>다시 확인</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1422"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1426"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1422"/>
        <source>Move</source>
        <translation>모바일</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1538"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1542"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1538"/>
        <source>Are you sure to delete&quot;</source>
        <translation>당신은 당신이 삭제 하시겠습니까&quot;</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1538"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1542"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1538"/>
        <source>&quot;?</source>
        <translation>&quot;?</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1540"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1544"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1540"/>
        <source>Are you sure to delete </source>
        <translation>당신은 당신이 삭제 하시겠습니까이</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1540"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1544"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1540"/>
        <source> items?</source>
        <translation>상품?</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1880"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1884"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1880"/>
        <source>Finish uploading: </source>
        <translation>업로드 :</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1881"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1886"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1894"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1899"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1885"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1890"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1898"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1903"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1881"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1886"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1894"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1899"/>
        <source>From</source>
        <translation>부터</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1881"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1886"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1894"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1899"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1885"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1890"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1898"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1903"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1881"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1886"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1894"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1899"/>
        <source> to </source>
        <translation>에</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1885"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1889"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1885"/>
        <source>Finish downloading: </source>
        <translation>다운로드 :</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1893"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1897"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1893"/>
        <source>Upload failed: </source>
        <translation>업로드에 실패했습니다 :</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1898"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1902"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1898"/>
        <source>Download failed: </source>
        <translation>다운로드 실패 :</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1952"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="1953"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1956"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="1957"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1952"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="1953"/>
        <source>Continue</source>
        <translation>계속</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2127"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2168"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2130"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2170"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2126"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2166"/>
        <source>Desktop</source>
        <translation>바탕 화면</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2198"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2212"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2200"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2214"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2196"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2210"/>
        <source>Name</source>
        <translation>이름</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2198"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2200"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2196"/>
        <source>Target</source>
        <translation>목표</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2198"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2212"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2200"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2214"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2196"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2210"/>
        <source>Size</source>
        <translation>크기</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2212"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2214"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2210"/>
        <source>Modification time</source>
        <translation>수정</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2212"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2214"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2210"/>
        <source>Type</source>
        <translation>유형</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2346"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2375"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2348"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2375"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2344"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2371"/>
        <source>Documents</source>
        <translation>내 문서</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2348"/>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2376"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2350"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2376"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2346"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2372"/>
        <source>Computer</source>
        <translation>컴퓨터</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2438"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2438"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2434"/>
        <source>Finish deleting </source>
        <translation>삭제</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2443"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2443"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2439"/>
        <source>Delete </source>
        <translation>삭제</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2443"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2443"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2439"/>
        <source> failed</source>
        <translation>실패</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/bk/2/filemanagerform.cpp" line="2453"/>
        <location filename="../plugin/NewFileManager/bk/filemanagerform.cpp" line="2453"/>
        <location filename="../plugin/NewFileManager/filemanagerform.cpp" line="2449"/>
        <source>New Folder</source>
        <translation>새 폴더</translation>
    </message>
</context>
<context>
    <name>GeneralSettingWindow</name>
    <message>
        <location filename="qml/GeneralSettingWindow.qml" line="82"/>
        <source>Sunlogin control client</source>
        <translation>해바라기 리모트 주체</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindow.qml" line="104"/>
        <location filename="qml/GeneralSettingWindow.qml" line="131"/>
        <location filename="qml/GeneralSettingWindow.qml" line="133"/>
        <location filename="qml/GeneralSettingWindow.qml" line="189"/>
        <location filename="qml/GeneralSettingWindow.qml" line="199"/>
        <location filename="qml/GeneralSettingWindow.qml" line="240"/>
        <source>General</source>
        <translation>통용</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindow.qml" line="134"/>
        <location filename="qml/GeneralSettingWindow.qml" line="230"/>
        <source>Message</source>
        <translation>정보</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindow.qml" line="292"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindow.qml" line="307"/>
        <source>OK</source>
        <translation>결정</translation>
    </message>
</context>
<context>
    <name>GeneralSettingWindowPage1</name>
    <message>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="36"/>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="49"/>
        <source>Login automatically after starting</source>
        <translation>부팅시 자동실행</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="37"/>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="75"/>
        <source>Login/Logout:</source>
        <translation>로그온, 로그오프：</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="38"/>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="101"/>
        <source>Need to confirm when exit</source>
        <translation>종료 확인 창이 뜹니다</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="43"/>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="81"/>
        <source>AutoLogin</source>
        <translation>자동 로그인</translation>
    </message>
    <message>
        <source>Save camera video files to :</source>
        <translation type="obsolete">을 여기에 저장：</translation>
    </message>
    <message>
        <source>Choose</source>
        <translation type="obsolete">선택</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage1.qml" line="41"/>
        <source>Restore default</source>
        <translation>설정복원</translation>
    </message>
    <message>
        <source>language:</source>
        <translation type="obsolete">언어설정:</translation>
    </message>
</context>
<context>
    <name>GeneralSettingWindowPage11</name>
    <message>
        <source>Login automatically after starting</source>
        <translation type="obsolete">부팅시 자동실행</translation>
    </message>
    <message>
        <source>Login/Logout:</source>
        <translation type="obsolete">로그온, 로그오프：</translation>
    </message>
    <message>
        <source>Need to confirm when exit</source>
        <translation type="obsolete">종료 확인 창이 뜹니다</translation>
    </message>
    <message>
        <source>Restore default</source>
        <translation type="obsolete">설정복원</translation>
    </message>
    <message>
        <source>language:</source>
        <translation type="obsolete">언어설정:</translation>
    </message>
    <message>
        <source>AutoLogin</source>
        <translation type="obsolete">자동 로그인</translation>
    </message>
</context>
<context>
    <name>GeneralSettingWindowPage2</name>
    <message>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="14"/>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="33"/>
        <source>Turn off all remind sounds and bubbles</source>
        <translation>음소거 및 깜빡이닫기</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="15"/>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="58"/>
        <source>Remind:</source>
        <translation>표시：</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="16"/>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="64"/>
        <source>Remind bubbles</source>
        <translation>깜빡이표시</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="17"/>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="85"/>
        <source>Remind sounds</source>
        <translation>소리켬</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="18"/>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="111"/>
        <source>Host on-line:</source>
        <translation>호스트 온라인：</translation>
    </message>
    <message>
        <location filename="qml/GeneralSettingWindowPage2.qml" line="19"/>
        <source>Restore default</source>
        <translation>설정복원</translation>
    </message>
</context>
<context>
    <name>HostAddSuccessWindow</name>
    <message>
        <location filename="qml/HostAddSuccessWindow.qml" line="50"/>
        <location filename="qml/HostAddSuccessWindow.qml" line="69"/>
        <location filename="qml/HostAddSuccessWindow.qml" line="75"/>
        <source>Add host</source>
        <translation>데스크톱 추가</translation>
    </message>
    <message>
        <location filename="qml/HostAddSuccessWindow.qml" line="76"/>
        <location filename="qml/HostAddSuccessWindow.qml" line="125"/>
        <source>Host added successfully, please use the corresponding key ID for host login.</source>
        <translation>해바라기 호스트 추가성공, 대응활성화코드로 로그인하세요。</translation>
    </message>
    <message>
        <location filename="qml/HostAddSuccessWindow.qml" line="77"/>
        <location filename="qml/HostAddSuccessWindow.qml" line="143"/>
        <source>Copy clipboard</source>
        <translation>클립보드</translation>
    </message>
    <message>
        <location filename="qml/HostAddSuccessWindow.qml" line="78"/>
        <location filename="qml/HostAddSuccessWindow.qml" line="158"/>
        <source>Continue adding</source>
        <translation>계속추가</translation>
    </message>
    <message>
        <location filename="qml/HostAddSuccessWindow.qml" line="79"/>
        <source>OK</source>
        <translation>결정</translation>
    </message>
</context>
<context>
    <name>HostAddWindow</name>
    <message>
        <location filename="qml/HostAddWindow.qml" line="114"/>
        <location filename="qml/HostAddWindow.qml" line="133"/>
        <location filename="qml/HostAddWindow.qml" line="139"/>
        <location filename="qml/HostAddWindow.qml" line="140"/>
        <location filename="qml/HostAddWindow.qml" line="218"/>
        <source>Add host</source>
        <translation>데스크톱 추가</translation>
    </message>
    <message>
        <source>You can add up to 5 hosts once</source>
        <translation type="obsolete">한 번에 최대 5대의 호스트 추가가능</translation>
    </message>
    <message>
        <source>Host name</source>
        <translation type="obsolete">호스트 명칭</translation>
    </message>
    <message>
        <location filename="qml/HostAddWindow.qml" line="141"/>
        <location filename="qml/HostAddWindow.qml" line="238"/>
        <source>Add camera</source>
        <translation>카메라 추가</translation>
    </message>
    <message>
        <location filename="qml/HostAddWindow.qml" line="142"/>
        <location filename="qml/HostAddWindow.qml" line="253"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="qml/HostAddWindow.qml" line="143"/>
        <location filename="qml/HostAddWindow.qml" line="269"/>
        <source>OK</source>
        <translation>결정</translation>
    </message>
    <message>
        <location filename="qml/HostAddWindow.qml" line="175"/>
        <source>over limit amount, upgrade then you can add more hosts</source>
        <translation>호스트 제한에 도달하기 위해 더 많은 호스트를 추가로 업그레이드</translation>
    </message>
</context>
<context>
    <name>HostInfoWindow</name>
    <message>
        <location filename="qml/HostInfoWindow.qml" line="61"/>
        <location filename="qml/HostInfoWindow.qml" line="69"/>
        <location filename="qml/HostInfoWindow.qml" line="138"/>
        <source>Host info</source>
        <oldsource>Host properties</oldsource>
        <translation>호스트 속성</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindow.qml" line="62"/>
        <location filename="qml/HostInfoWindow.qml" line="236"/>
        <source>Common</source>
        <translation>일반</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindow.qml" line="63"/>
        <location filename="qml/HostInfoWindow.qml" line="255"/>
        <source>Details</source>
        <translation>상세정보</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindow.qml" line="64"/>
        <location filename="qml/HostInfoWindow.qml" line="282"/>
        <source>OK</source>
        <translation>결정</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindow.qml" line="296"/>
        <source>Host name cannot be empty</source>
        <translation>호스트 이름은 빈 칸으로 남겨둘 수 없습니다</translation>
    </message>
</context>
<context>
    <name>HostInfoWindowPage1</name>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="39"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="65"/>
        <source>Never logged in</source>
        <translation>비로그인</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="55"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="110"/>
        <source>Host name:</source>
        <translation>호스트 명칭：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="56"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="123"/>
        <source>Host description:</source>
        <translation>호스트 묘사：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="57"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="135"/>
        <source>Tag:</source>
        <translation>라벨：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="58"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="147"/>
        <source>Key ID:</source>
        <translation>코드：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="59"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="171"/>
        <source>Open modules:</source>
        <translation>모듈부팅：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="60"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="183"/>
        <source>Created time:</source>
        <translation>생성시간：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="61"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="195"/>
        <source>Last login:</source>
        <translation>최근 로그인：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="62"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="298"/>
        <source>Remote control module</source>
        <translation>원격조정모듈</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="63"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="311"/>
        <source>VPN module</source>
        <translation>VPN 모듈</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="66"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="159"/>
        <source>Login:</source>
        <translation>로그인：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage1.qml" line="67"/>
        <location filename="qml/HostInfoWindowPage1.qml" line="274"/>
        <source>AutoLogin</source>
        <translation>자동 로그인</translation>
    </message>
</context>
<context>
    <name>HostInfoWindowPage2</name>
    <message>
        <location filename="qml/HostInfoWindowPage2.qml" line="38"/>
        <location filename="qml/HostInfoWindowPage2.qml" line="76"/>
        <source>Contact information:</source>
        <translation>연락처：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage2.qml" line="39"/>
        <location filename="qml/HostInfoWindowPage2.qml" line="89"/>
        <source>Name:</source>
        <translation>성명：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage2.qml" line="40"/>
        <location filename="qml/HostInfoWindowPage2.qml" line="101"/>
        <source>Telephone:</source>
        <translation>연결전화：</translation>
    </message>
    <message>
        <location filename="qml/HostInfoWindowPage2.qml" line="41"/>
        <location filename="qml/HostInfoWindowPage2.qml" line="113"/>
        <source>E-mail:</source>
        <translation>우편주소：</translation>
    </message>
</context>
<context>
    <name>HostList</name>
    <message>
        <source>Wakeup server has expired,please renew</source>
        <translation type="obsolete">전환 서비스 만료되어 갱신하십시오</translation>
    </message>
    <message>
        <source>Wakeup server will be </source>
        <translation type="obsolete">서비스 전환됩니다</translation>
    </message>
    <message>
        <source> expire,please renew</source>
        <translation type="obsolete">만료, 갱신하십시오</translation>
    </message>
</context>
<context>
    <name>HostListModel</name>
    <message>
        <location filename="HostListModel.cpp" line="84"/>
        <location filename="HostListModel.cpp" line="155"/>
        <location filename="HostListModel.cpp" line="303"/>
        <source>Online</source>
        <translation>호스트 온라인</translation>
    </message>
    <message>
        <location filename="HostListModel.cpp" line="80"/>
        <location filename="HostListModel.cpp" line="160"/>
        <location filename="HostListModel.cpp" line="308"/>
        <source>Offline</source>
        <translation>호스트 오프라인</translation>
    </message>
    <message>
        <location filename="HostListModel.cpp" line="88"/>
        <location filename="HostListModel.cpp" line="204"/>
        <source>My device</source>
        <translation>내 설비</translation>
    </message>
</context>
<context>
    <name>HostLoginView</name>
    <message>
        <location filename="qml/HostLoginView.qml" line="18"/>
        <location filename="qml/HostLoginView.qml" line="406"/>
        <source>Unknown error!</source>
        <translation>오류불명！</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="27"/>
        <location filename="qml/HostLoginView.qml" line="199"/>
        <location filename="qml/HostLoginView.qml" line="221"/>
        <location filename="qml/HostLoginView.qml" line="222"/>
        <location filename="qml/HostLoginView.qml" line="295"/>
        <source>Host login</source>
        <translation>호스트 로그인</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="248"/>
        <source>User name or password can not be empty</source>
        <translation>아이디 혹은 비밀번호는 빈 칸으로 남겨둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="265"/>
        <source>Access Password can not be empty</source>
        <translation>접속 비밀번호는 빈 칸으로 남겨둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="223"/>
        <location filename="qml/HostLoginView.qml" line="324"/>
        <source>Access Password</source>
        <translation>접속 비밀번호</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="410"/>
        <source>Connect to the server failed!</source>
        <translation>서버연결오류!!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="413"/>
        <source>ControlID verification failed!</source>
        <translation>ControlID인증오류!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="416"/>
        <source>Cookie verification failed!</source>
        <translation>Cookie인증오류!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="419"/>
        <source>Bad request!</source>
        <translation>오류요청!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="422"/>
        <source>Host is not online!</source>
        <translation>호스트 오프라인!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="425"/>
        <source>Unknown remote host!</source>
        <translation>알수없는 원격호스트!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="428"/>
        <source>Server Error!</source>
        <translation>서버에러!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="431"/>
        <source>Request timed out!</source>
        <translation>시간초과!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="435"/>
        <source>User name or password is incorrect!</source>
        <translation>계정 또는 비밀번호 오류!</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="438"/>
        <source>std::exception</source>
        <translation>예외</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="441"/>
        <source>Check the status of the remote control failed</source>
        <translation>원격 제어 실패의 상태를 확인</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="444"/>
        <source>Check the login period failed</source>
        <translation>시간 제한 실패를 확인</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="447"/>
        <source>Check the login type failed</source>
        <translation>로그인 실패 확인</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="450"/>
        <source>Password can not be empty</source>
        <translation>암호는 비워 둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="453"/>
        <source>Create instance failed</source>
        <translation>인스턴스 실패를 만듭니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="456"/>
        <source>Login the host failed</source>
        <translation>실패한 호스트 로그인</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="459"/>
        <source>Remote control module has been closed</source>
        <translation>원격 제어 모듈이 닫혔습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="462"/>
        <source>Login failed with the way</source>
        <translation>로그인 실패</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="465"/>
        <source>The remote host did not response</source>
        <translation>원격 호스트가 응답하지 않습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="468"/>
        <source>Check the harass status failed</source>
        <translation>실패 방지 성희롱의 상태를 확인</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="471"/>
        <source>Rejected the connection request</source>
        <translation>원격 호스트가 연결 요청을 거부</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="474"/>
        <source>Verify strings can not be empty</source>
        <translation>기호 문자열은 비워 둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="477"/>
        <source>Access denied,you can&apos;t access to the host in the following</source>
        <translation>원격 호스트가 연결 요청을 거부</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="480"/>
        <source>Wrong answer to anti-harassment</source>
        <translation>대답은 정확하지 않습니다, ​​다시 입력 해주세요</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="483"/>
        <source>Check the anti-harassment answer failed</source>
        <translation>검출 대답은 실패</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="486"/>
        <source>input empty</source>
        <translation>입력이 비어 있습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="489"/>
        <source>input wrong</source>
        <translation>입력오류</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="492"/>
        <source>vertify failed</source>
        <translation>검증 실패</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="495"/>
        <source>pwd wrong</source>
        <translation>인증 비밀번호 오류</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="498"/>
        <source>query empty</source>
        <translation>검색 결과가 없습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="501"/>
        <source>CONNECT_SOCKET_URLS_HPP connect_socket</source>
        <translation>CONNECT_SOCKET_URLS_HPP connect_socket</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="504"/>
        <source>auth(2) failed</source>
        <translation>auth(3) 오류</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="507"/>
        <source>auth(3) failed</source>
        <translation>auth(3) 오류</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="510"/>
        <source>rpc_digest not correct</source>
        <translation>RPC 에러 개요</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="513"/>
        <source>change fast_code failed</source>
        <translation>빠른 접속 코드 실패</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="516"/>
        <source>db query not found key</source>
        <translation>데이터베이스 키워드를 찾을 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="598"/>
        <source>Switch to access password logon</source>
        <translation>전환을 클릭하고 접속 비밀번호 인증</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="598"/>
        <source>Switch to Windows Account logon</source>
        <translation>전환을 클릭하고 윈도우 계정 인증</translation>
    </message>
    <message>
        <location filename="qml/HostLoginView.qml" line="224"/>
        <location filename="qml/HostLoginView.qml" line="556"/>
        <source>Auto login</source>
        <translation>자동 로그인</translation>
    </message>
</context>
<context>
    <name>HostLogin_Account</name>
    <message>
        <location filename="qml/HostLogin_Account.qml" line="14"/>
        <location filename="qml/HostLogin_Account.qml" line="137"/>
        <source>Windows account</source>
        <translation>윈도우 계정</translation>
    </message>
    <message>
        <location filename="qml/HostLogin_Account.qml" line="15"/>
        <location filename="qml/HostLogin_Account.qml" line="208"/>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
</context>
<context>
    <name>HostLogin_Loading</name>
    <message>
        <location filename="qml/HostLogin_Loading.qml" line="23"/>
        <source>Logining...</source>
        <translation>로그인중…</translation>
    </message>
</context>
<context>
    <name>HostMgrAdapter</name>
    <message>
        <location filename="hostmgradapter.cpp" line="171"/>
        <source>Host name can not be longer than 20</source>
        <translation>호스트 이름은 20자를 초과 할 수 없습니다</translation>
    </message>
    <message>
        <source>You can add up to 5 hosts once</source>
        <translation type="obsolete">최대 5대의 호스트 추가가능</translation>
    </message>
    <message>
        <location filename="hostmgradapter.cpp" line="166"/>
        <source>Host name cannot be empty</source>
        <translation>호스트 이름은 빈 칸으로 남겨둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="hostmgradapter.cpp" line="187"/>
        <source>Camera name cannot be empty</source>
        <translation>카메라 이름은 비워 둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="hostmgradapter.cpp" line="192"/>
        <source>Camera uid cannot be empty</source>
        <translation>카메라 UID는 비워 둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="hostmgradapter.cpp" line="199"/>
        <source>No this camera on Lan</source>
        <translation>카메라는 LAN에없는</translation>
    </message>
    <message>
        <location filename="hostmgradapter.cpp" line="448"/>
        <location filename="hostmgradapter.cpp" line="461"/>
        <source>Add host failed</source>
        <translation>호스트가 실패 추가</translation>
    </message>
</context>
<context>
    <name>HostOnlineTip</name>
    <message>
        <source>Host </source>
        <translation type="obsolete">호스트</translation>
    </message>
    <message>
        <source>is on-line!</source>
        <translation type="obsolete">온라인중!</translation>
    </message>
    <message>
        <location filename="qml/HostOnlineTip.qml" line="28"/>
        <source>Host &lt;b&gt;</source>
        <translation>호스트 &lt;b&gt;</translation>
    </message>
    <message>
        <location filename="qml/HostOnlineTip.qml" line="28"/>
        <source>&lt;/b&gt; is on-line!</source>
        <translation>&lt;/b&gt; 온라인중!</translation>
    </message>
</context>
<context>
    <name>InteractDialog</name>
    <message>
        <location filename="../plugin/NewFileManager/interactdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/interactdialog.ui" line="26"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/interactdialog.ui" line="39"/>
        <source>OK</source>
        <translation>확정</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/interactdialog.ui" line="80"/>
        <source>Are you sure to delete files?</source>
        <translation>당신은 확실히 당신이 파일을 삭제 하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../plugin/NewFileManager/interactdialog.ui" line="99"/>
        <source>Cover all other files</source>
        <translation>다른 파일 폴더를 덮어 쓰기</translation>
    </message>
    <message>
        <source>取消</source>
        <translation type="obsolete">취소</translation>
    </message>
    <message>
        <source>确定</source>
        <translation type="obsolete">결정</translation>
    </message>
    <message>
        <source>确定要删除文件吗？</source>
        <translation type="obsolete">당신은 확실히 당신이 파일을 삭제 하시겠습니까?</translation>
    </message>
    <message>
        <source>覆盖文件夹其他文件</source>
        <translation type="obsolete">다른 파일 폴더를 덮어 쓰기</translation>
    </message>
    <message>
        <source>覆盖重复文件</source>
        <translation type="obsolete">중복 파일을 덮어 쓰기</translation>
    </message>
</context>
<context>
    <name>LockWindow</name>
    <message>
        <location filename="qml/LockWindow.qml" line="108"/>
        <source>Please enter the lock code</source>
        <translation>잠금 비밀번호를 입력해주세요</translation>
    </message>
    <message>
        <location filename="qml/LockWindow.qml" line="41"/>
        <source>Inconsistent password, please re-enter</source>
        <translation>비밀번호가 일치하지 않습니다. 다시 입력해주세요</translation>
    </message>
    <message>
        <location filename="qml/LockWindow.qml" line="150"/>
        <source>Please re-enter the lock code</source>
        <translation>잠금 비밀번호를 입력해주세요</translation>
    </message>
</context>
<context>
    <name>LoginWindow</name>
    <message>
        <location filename="qml/LoginWindow.qml" line="12"/>
        <location filename="qml/LoginWindow.qml" line="69"/>
        <location filename="qml/LoginWindow.qml" line="298"/>
        <source>Account</source>
        <translation>계정</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="16"/>
        <location filename="qml/LoginWindow.qml" line="70"/>
        <location filename="qml/LoginWindow.qml" line="358"/>
        <source>Password</source>
        <translation>비밀번호</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="29"/>
        <location filename="qml/LoginWindow.qml" line="789"/>
        <source>Unknown error!</source>
        <oldsource>nknown error!</oldsource>
        <translation>오류불명！</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="74"/>
        <location filename="qml/LoginWindow.qml" line="246"/>
        <source>Cancel login</source>
        <translation>로그인 취소</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="71"/>
        <location filename="qml/LoginWindow.qml" line="484"/>
        <source>AutoLogin</source>
        <translation>자동 로그인</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="33"/>
        <source>Sunlogin control client</source>
        <translation>해바라기 리모트 주체</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="72"/>
        <location filename="qml/LoginWindow.qml" line="509"/>
        <source>Forget</source>
        <translation>비밀번호찾기</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="73"/>
        <location filename="qml/LoginWindow.qml" line="616"/>
        <source>Register</source>
        <translation>계정등록</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="399"/>
        <location filename="qml/LoginWindow.qml" line="452"/>
        <source>username or password can&apos;t be empty</source>
        <translation>사용자 이름이나 암호가 비어 있습니다</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="567"/>
        <source>Send quick access</source>
        <translation>빠른 원격 제어를 시작합니다</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="783"/>
        <source>Incorrect username or password!</source>
        <translation>계정 또는 비밀번호 오류!</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="786"/>
        <source>Connect server failed!</source>
        <translation>서버연결오류!</translation>
    </message>
    <message>
        <location filename="qml/LoginWindow.qml" line="792"/>
        <source>the version too low,please update to new version!</source>
        <translation>버전이 너무 낮은, 새로운 버전으로 업데이트하시기 바랍니다!</translation>
    </message>
</context>
<context>
    <name>MacMainWindow</name>
    <message>
        <location filename="macmainwindow.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="macmainwindow.ui" line="26"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MainForm</name>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="100"/>
        <source>Take picture</source>
        <translation>잡아 성공</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="678"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="689"/>
        <source>Video files will be stored to </source>
        <translation>녹화파일을 여기에 저장</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="772"/>
        <source>There is no video data recorded!</source>
        <translation>어떠한 카메라는 데이터를 기록 할 수 없다!</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="778"/>
        <source>End of video, video file saved </source>
        <translation>녹화종료, 녹화파일 이미 저장</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="903"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1336"/>
        <source>Failed to open the camera.</source>
        <translation>캠 열기 실패</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="916"/>
        <source>Loading....</source>
        <translation>로딩중</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1092"/>
        <source>This camera have no resolution info</source>
        <translation>이 카메라는 해상도 정보를하지 않습니다</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1109"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1338"/>
        <source>The remote host doesn&amp;apos;t have a camera.</source>
        <translation>원격호스트에 캠이 없습니다</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1247"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1258"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1279"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1301"/>
        <source>sound open</source>
        <translation>오픈 사운드</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1250"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1261"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1285"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1295"/>
        <source>sound close</source>
        <translation>복창</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1339"/>
        <source>Switch</source>
        <translation>전환</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1340"/>
        <source>Sound</source>
        <translation>소리</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1341"/>
        <source>Recorder</source>
        <translation>녹화</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1342"/>
        <source>Full-screen</source>
        <translation>전체 스크린</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1344"/>
        <source>SetSize</source>
        <translation>의 크기를 설정</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1345"/>
        <source>SetDirection</source>
        <translation>설정 방향</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1346"/>
        <source>SetPosition</source>
        <translation>설정 위치</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1347"/>
        <source>TakePhotos</source>
        <translation>잡아</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1348"/>
        <source>ToSay</source>
        <translation>음성</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1349"/>
        <source>ToSet</source>
        <translation>설정</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1334"/>
        <location filename="../plugin/OrayDesktopControl/mainform.cpp" line="149"/>
        <source>Loading...</source>
        <translation>연결중…</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="14"/>
        <location filename="../plugin/OrayChatClient/MainForm.ui" line="14"/>
        <location filename="../plugin/OrayCMDClient/mainform.ui" line="14"/>
        <location filename="../plugin/OrayDesktopControl/mainform.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="53"/>
        <location filename="../plugin/OrayChatClient/MainForm.ui" line="50"/>
        <location filename="../plugin/OrayCMDClient/mainform.ui" line="50"/>
        <location filename="../plugin/OrayDesktopControl/mainform.ui" line="53"/>
        <source>正在载入....</source>
        <translation>연결중…</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="153"/>
        <source>00:00</source>
        <translation>5-60s {00:00?}</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="210"/>
        <source>全屏</source>
        <translation>전체 스크린</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="269"/>
        <source>声音</source>
        <translation>소리</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="325"/>
        <source>录像</source>
        <translation>녹화</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="381"/>
        <source>切换</source>
        <translation>전환</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="426"/>
        <source>放大缩小</source>
        <translation>줌</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="1250"/>
        <source>Take pic</source>
        <translation>잡아 성공</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="1284"/>
        <source>sound</source>
        <translation>소리</translation>
    </message>
    <message>
        <source>00:00:00</source>
        <translation type="obsolete">5-60s {00:00:00?}</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="727"/>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="894"/>
        <source>录像文件将保存在</source>
        <translation>녹화파일을 여기에 저장</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="848"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;test&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ff872b;&quot;&gt;查看&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="1031"/>
        <source> HD</source>
        <translation> 고화질</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="1096"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="92"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1453"/>
        <source>SD</source>
        <translation>청 표</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="1149"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="91"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="93"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1466"/>
        <source>HD</source>
        <translation>고화질</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.ui" line="1202"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="94"/>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="1479"/>
        <source>UHD</source>
        <translation>초과 청</translation>
    </message>
    <message>
        <source>  高清</source>
        <translation type="obsolete">고화질</translation>
    </message>
    <message>
        <source>标清</source>
        <translation type="obsolete">청 표</translation>
    </message>
    <message>
        <source>高清</source>
        <translation type="obsolete">고화질</translation>
    </message>
    <message>
        <source>超清</source>
        <translation type="obsolete">초과 청</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="78"/>
        <source>Send File</source>
        <translation>파일 보내기</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="79"/>
        <source>Send</source>
        <translation>보내기</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="324"/>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="411"/>
        <source>Me</source>
        <translation>나</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="332"/>
        <source>far away</source>
        <translation>고소당하다. 단</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="362"/>
        <source>Save File</source>
        <translation>파일 저장</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="378"/>
        <source>Whether to recive file:</source>
        <translation>혹시 수신 파일：</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="379"/>
        <source>Size:</source>
        <translation>크기:</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="381"/>
        <source>Chat</source>
        <translation>대화</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="423"/>
        <source>Send file</source>
        <translation>파일 보내기</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="476"/>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="486"/>
        <source>recive file:</source>
        <translation>수신 파일：</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="477"/>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="497"/>
        <source> failed, </source>
        <translation>실패，</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="487"/>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="507"/>
        <source> done, </source>
        <translation>성공，</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="496"/>
        <location filename="../plugin/OrayChatClient/MainForm.cpp" line="506"/>
        <source>Send file:</source>
        <translation>파일 보내기：</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/mainform.cpp" line="958"/>
        <location filename="../plugin/OrayDesktopControl/mainform.cpp" line="172"/>
        <source>Loading timed out, please refresh the list and try again</source>
        <translation>로그인 타임 아웃은, 목록을 새로 다시 로그인</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/mainform.cpp" line="184"/>
        <source>The remote host does&apos;t allow desktop</source>
        <translation>권한이 부족합니다, 당신은 원격 데스크톱에 로그인 할 수 없습니다</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/mainform.cpp" line="190"/>
        <source>The remote failed to login desktop</source>
        <translation>원격 데스크톱 로그인 실패</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="qml/MainWindow.qml" line="16"/>
        <location filename="qml/MainWindow.qml" line="17"/>
        <location filename="qml/MainWindow.qml" line="1371"/>
        <location filename="qml/MainWindow.qml" line="1587"/>
        <source>Sunlogin control client</source>
        <translation>해바라기 리모트 주체</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="704"/>
        <source>The host is Linux host,please control it by web</source>
        <translation>리눅스 호스트에 대한 호스트, WEB에 의해 제어되어주세요</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="962"/>
        <source>Free Service</source>
        <translation>무료</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="966"/>
        <source>Pro Service</source>
        <translation>전문</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="970"/>
        <source>Enterprise Service</source>
        <translation>비즈니스</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="980"/>
        <source>Free service</source>
        <translation>무료</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="1079"/>
        <source>Your account logined in another place</source>
        <translation>귀하의 계정이 다른 곳에서 로그온되었습니다</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="1372"/>
        <location filename="qml/MainWindow.qml" line="2052"/>
        <source>Search</source>
        <translation>탐색</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="1817"/>
        <source>Change state</source>
        <translation>온라인으로 전환</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="1925"/>
        <source>Add host</source>
        <translation>데스크톱 추가</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="1952"/>
        <source>Quick remote</source>
        <translation>빠른 원격 액세스</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="1978"/>
        <source>Screen wall</source>
        <translation>屏幕墙</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2130"/>
        <source>Clear</source>
        <translation>빈</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2152"/>
        <source>Refresh</source>
        <translation>새로 고침</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2280"/>
        <source>Host list</source>
        <translation>목록 호스트</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2357"/>
        <source>Tag list</source>
        <translation>태그 목록</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2438"/>
        <source>Histroy list</source>
        <translation>기록 목록</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2461"/>
        <source>Service will be expired锛�</source>
        <translation>서비스 만료되기</translation>
    </message>
    <message>
        <source>Service will be expired，</source>
        <translation type="obsolete">당신의 서비스가 만료 될，</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2469"/>
        <source>Renew</source>
        <translation>지금 갱신</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2502"/>
        <source>close</source>
        <translation>종료</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2574"/>
        <source>No search results</source>
        <translation>로컬 검색 결과가 없습니다</translation>
    </message>
    <message>
        <location filename="qml/MainWindow.qml" line="2617"/>
        <source>Connect</source>
        <translation>연결</translation>
    </message>
    <message>
        <source>Initiate fast remote control</source>
        <translation type="obsolete">빠른 원격 제어를 시작합니다</translation>
    </message>
</context>
<context>
    <name>MessageBox</name>
    <message>
        <location filename="qml/MessageBox.qml" line="40"/>
        <location filename="qml/MessageBox.qml" line="49"/>
        <location filename="qml/MessageBox.qml" line="162"/>
        <source>upgrade Now</source>
        <translation>지금 업그레이드하기</translation>
    </message>
    <message>
        <location filename="qml/MessageBox.qml" line="41"/>
        <location filename="qml/MessageBox.qml" line="50"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="qml/MessageBox.qml" line="32"/>
        <location filename="qml/MessageBox.qml" line="132"/>
        <source>OK</source>
        <translation>결정</translation>
    </message>
</context>
<context>
    <name>MicroPhoneDlg</name>
    <message>
        <location filename="../plugin/CameraPlayer/microphonedlg.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
<context>
    <name>ModuleChoose</name>
    <message>
        <location filename="qml/ModuleChoose.qml" line="164"/>
        <location filename="qml/ModuleChoose.qml" line="215"/>
        <source>Desktop control</source>
        <translation>데스크톱 제어</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="165"/>
        <location filename="qml/ModuleChoose.qml" line="249"/>
        <source>Desktop view</source>
        <translation>데스크톱 보기</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="166"/>
        <location filename="qml/ModuleChoose.qml" line="283"/>
        <source>Camera</source>
        <translation>캠</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="167"/>
        <location filename="qml/ModuleChoose.qml" line="445"/>
        <source>Shutdown</source>
        <translation>끄기</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="319"/>
        <source>file control</source>
        <translation>원격 파일</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="355"/>
        <source>CMD</source>
        <translation>CMD</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="389"/>
        <source>Additional Function</source>
        <translation>더 많은 기능</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="470"/>
        <location filename="qml/ModuleChoose.qml" line="548"/>
        <source>Prompt</source>
        <translation>표시</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="470"/>
        <source>Are you sure to shut down?</source>
        <translation>리모트대상을 종료할까요?</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="168"/>
        <location filename="qml/ModuleChoose.qml" line="523"/>
        <source>Restart</source>
        <translation>재시작</translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="72"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="qml/ModuleChoose.qml" line="548"/>
        <source>Are you sure to restart?</source>
        <translation>리모트대상을 재시작할까요?</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">아니오</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">네</translation>
    </message>
</context>
<context>
    <name>MySimpleListView</name>
    <message>
        <location filename="qml/MySimpleListView.qml" line="15"/>
        <location filename="qml/MySimpleListView.qml" line="33"/>
        <source>Host</source>
        <translation>호스트</translation>
    </message>
    <message>
        <location filename="qml/MySimpleListView.qml" line="16"/>
        <location filename="qml/MySimpleListView.qml" line="44"/>
        <source>Key code</source>
        <translation>코드</translation>
    </message>
</context>
<context>
    <name>NewbieHelp</name>
    <message>
        <location filename="qml/NewbieHelp.qml" line="40"/>
        <source>How to add a remote computer?</source>
        <translation>리모트 대상 컴퓨터는 어떻게 추가하나요？</translation>
    </message>
    <message>
        <location filename="qml/NewbieHelp.qml" line="48"/>
        <source>Install Sunlogin Remote Client on your destination computer</source>
        <translation>제어할 컴퓨터에 해바라기 리모트를 설치해주세요</translation>
    </message>
    <message>
        <location filename="qml/NewbieHelp.qml" line="65"/>
        <source>Retrieve Sunlogin Remote Client: </source>
        <translation>해바라기 리모트 다운로드：</translation>
    </message>
    <message>
        <location filename="qml/NewbieHelp.qml" line="113"/>
        <source>Sign in Sunlogin Remote Client using your current account</source>
        <translation>귀하의 계정으로 해바라기 리모트에 로그인 해주세요</translation>
    </message>
    <message>
        <location filename="qml/NewbieHelp.qml" line="135"/>
        <source>Remote computer will appear in your host list</source>
        <translation>호스트 목록에 제어대상 컴퓨터가 나타납니다</translation>
    </message>
</context>
<context>
    <name>OneWidgetContainer</name>
    <message>
        <location filename="../plugin/CameraPlayer/onewidgetcontainer.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
<context>
    <name>OnlineCameraForm</name>
    <message>
        <source>Video files will be stored to </source>
        <translation type="obsolete">녹화파일을 여기에 저장</translation>
    </message>
    <message>
        <source>End of video, video file saved </source>
        <translation type="obsolete">녹화종료, 녹화파일 이미 저장</translation>
    </message>
    <message>
        <source>Failed to open the camera.</source>
        <translation type="obsolete">캠 열기 실패</translation>
    </message>
    <message>
        <source>Loading....</source>
        <translation type="obsolete">로딩중</translation>
    </message>
    <message>
        <source>The remote host doesn&amp;apos;t have a camera.</source>
        <translation type="obsolete">원격호스트에 캠이 없습니다</translation>
    </message>
    <message>
        <source>Switch</source>
        <translation type="obsolete">전환</translation>
    </message>
    <message>
        <source>Sound</source>
        <translation type="obsolete">소리</translation>
    </message>
    <message>
        <source>Recorder</source>
        <translation type="obsolete">녹화</translation>
    </message>
</context>
<context>
    <name>OnlineForm</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Form</translation>
    </message>
    <message>
        <source>00:00</source>
        <translation type="obsolete">5-60s {00:00?}</translation>
    </message>
    <message>
        <source>00:00:00</source>
        <translation type="obsolete">5-60s {00:00:00?}</translation>
    </message>
</context>
<context>
    <name>OraySystemTray</name>
    <message>
        <location filename="oraysystemTray.cpp" line="245"/>
        <source>Unlock</source>
        <translation>언락</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="185"/>
        <location filename="oraysystemTray.cpp" line="257"/>
        <location filename="oraysystemTray.cpp" line="269"/>
        <source>Lock</source>
        <translation>잠금</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="182"/>
        <location filename="oraysystemTray.cpp" line="268"/>
        <source>Open main window</source>
        <translation>홈 화면</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="46"/>
        <location filename="oraysystemTray.cpp" line="215"/>
        <source>sunlogin remote</source>
        <translation>해바라기 리모트 주체</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="188"/>
        <location filename="oraysystemTray.cpp" line="270"/>
        <source>Change account</source>
        <translation>계정변경</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="191"/>
        <location filename="oraysystemTray.cpp" line="281"/>
        <source>Quit</source>
        <translation>종료</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="202"/>
        <source>Help</source>
        <translation>도움</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="203"/>
        <location filename="oraysystemTray.cpp" line="282"/>
        <source>About</source>
        <translation>관하여</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="205"/>
        <location filename="oraysystemTray.cpp" line="283"/>
        <source>Online upgrade</source>
        <translation>온라인 업그레이드</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="218"/>
        <source>
lock</source>
        <translation>잠금</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="223"/>
        <source>
offline</source>
        <translation>해제</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="226"/>
        <source>
online</source>
        <translation>온라인으로</translation>
    </message>
    <message>
        <location filename="oraysystemTray.cpp" line="229"/>
        <source>
loging</source>
        <translation>로그인</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">종료</translation>
    </message>
</context>
<context>
    <name>PluginConnector</name>
    <message>
        <source>Plugin does not exist</source>
        <translation type="obsolete">존재하지 않는 플러그인</translation>
    </message>
    <message>
        <source>Plugin error</source>
        <translation type="obsolete">플러그인이 올바르지 않습니다</translation>
    </message>
</context>
<context>
    <name>PluginConnectorStateForm</name>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.cpp" line="50"/>
        <source>Loading...</source>
        <translation>연결중…</translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.cpp" line="122"/>
        <source>P2P connection is being established</source>
        <translation>P2P연결 생성중 </translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.cpp" line="126"/>
        <source>Is requesting forwarding</source>
        <translation>발송요청중</translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.cpp" line="130"/>
        <source>Loginning</source>
        <translation>로그인중</translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.cpp" line="143"/>
        <source>Connection stopped</source>
        <translation>연결중단</translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.cpp" line="164"/>
        <source>Connection completed</source>
        <translation>연결됨</translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.ui" line="32"/>
        <source>正在连接...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnectorstateform.ui" line="48"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PluginContainer</name>
    <message>
        <location filename="plugincontainerUI.ui" line="23"/>
        <source>Sunlogin</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PluginManager</name>
    <message>
        <source>Remote desktop control</source>
        <translation type="obsolete">원격 데스크</translation>
    </message>
    <message>
        <source>Remote desktop view</source>
        <translation type="obsolete">데스크톱 보기</translation>
    </message>
    <message>
        <source>Remote camera</source>
        <translation type="obsolete">캠</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnector.cpp" line="196"/>
        <source>Plugin does not exist</source>
        <translation>존재하지 않는 플러그인</translation>
    </message>
    <message>
        <location filename="../plugin/PluginConnector/pluginconnector.cpp" line="206"/>
        <location filename="../plugin/PluginConnector/pluginconnector.cpp" line="210"/>
        <location filename="../plugin/PluginConnector/pluginconnector.cpp" line="220"/>
        <source>Plugin error</source>
        <translation>플러그인이 존재하지 않습니다</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">네</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">아니오</translation>
    </message>
    <message>
        <location filename="pluginmanager.cpp" line="603"/>
        <source>Remote filemanager </source>
        <translation>원격 파일 </translation>
    </message>
    <message>
        <location filename="pluginmanager.cpp" line="626"/>
        <source>Remote CMD </source>
        <translation>CMD </translation>
    </message>
    <message>
        <location filename="pluginmanager.cpp" line="330"/>
        <source>Remote desktop control</source>
        <translation>데스크톱 제어 </translation>
    </message>
    <message>
        <location filename="pluginmanager.cpp" line="416"/>
        <source>Remote desktop view</source>
        <translation>데스크톱 보기 </translation>
    </message>
    <message>
        <location filename="pluginmanager.cpp" line="500"/>
        <source>Remote camera</source>
        <translation>캠 </translation>
    </message>
    <message>
        <location filename="pluginmanager.cpp" line="646"/>
        <source>Remote Chat </source>
        <translation>대화</translation>
    </message>
</context>
<context>
    <name>QuickCodeLogin</name>
    <message>
        <location filename="qml/QuickCodeLogin.qml" line="140"/>
        <source>Enter the quick access code to initiate remote control request</source>
        <translation>원격 제어를 시작합니다</translation>
    </message>
    <message>
        <location filename="qml/QuickCodeLogin.qml" line="112"/>
        <location filename="qml/QuickCodeLogin.qml" line="161"/>
        <source>Quick access</source>
        <translation>빠른 액세스</translation>
    </message>
    <message>
        <location filename="qml/QuickCodeLogin.qml" line="277"/>
        <source>Enter access code</source>
        <translation>빠른 액세스 코드를 입력하세요</translation>
    </message>
    <message>
        <location filename="qml/QuickCodeLogin.qml" line="312"/>
        <source>Connect</source>
        <translation>연결</translation>
    </message>
    <message>
        <location filename="qml/QuickCodeLogin.qml" line="333"/>
        <source>Support Sunlogin6 or laster</source>
        <translation>이 기능은 해바라기 클라이언트 버전 6.0 이상을 지원합니다!</translation>
    </message>
    <message>
        <location filename="qml/QuickCodeLogin.qml" line="465"/>
        <source>Clear</source>
        <translation>지우기</translation>
    </message>
</context>
<context>
    <name>QuickCodeLoginWelcome</name>
    <message>
        <location filename="qml/QuickCodeLoginWelcome.qml" line="115"/>
        <source>Quick access type without logining</source>
        <translation>빠른 원격 제어는 새로운 방식으로 기록되지 않습니다</translation>
    </message>
    <message>
        <location filename="qml/QuickCodeLoginWelcome.qml" line="126"/>
        <source>Find quick code in Sunlogin7</source>
        <oldsource>Find quick code in Sunlogin6</oldsource>
        <translation>클라이언트 해바라기 7에 빠르게 액세스 코드 찾기</translation>
    </message>
    <message>
        <location filename="qml/QuickCodeLoginWelcome.qml" line="138"/>
        <source>Downloading Sunlogin7</source>
        <oldsource>Downloading Sunlogin6</oldsource>
        <translation>해바라기 7을 다운로드하여 설치</translation>
    </message>
    <message>
        <location filename="qml/QuickCodeLoginWelcome.qml" line="68"/>
        <source>Welcome to use quick access</source>
        <translation>歡迎使用快速遠控</translation>
    </message>
</context>
<context>
    <name>RemoteDesktopBottomBar</name>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="376"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="383"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="390"/>
        <source>Prompt</source>
        <translation>알림</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="376"/>
        <source>Are you sure to logout?</source>
        <translation>로그아웃 하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="383"/>
        <source>Are you sure to restart?</source>
        <translation>재부팅하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="390"/>
        <source>Are you sure to poweroff?</source>
        <translation>끄시겠습니까?</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="311"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="697"/>
        <source>Enable black screen model</source>
        <translation>블랙스크린 모드 사용</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="165"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="309"/>
        <source>Screen </source>
        <translation>화면 </translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="312"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="698"/>
        <source>Disable black screen model</source>
        <translation>블랙스크린 모드 종료</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="314"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="713"/>
        <source>Control model</source>
        <translation>제어모드</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="315"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="714"/>
        <source>Watch model</source>
        <translation>화면보기모드</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="317"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="731"/>
        <source>Lock</source>
        <translation>잠금</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="318"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="732"/>
        <source>Logout</source>
        <translation>로그오프</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="319"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="733"/>
        <source>Restart</source>
        <translation>재시작</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="320"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="734"/>
        <source>Poweroff</source>
        <translation>끄기</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="321"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="735"/>
        <source>Explorer</source>
        <translation>익스플로러</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="322"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="736"/>
        <source>Task manager</source>
        <translation>작업관리자</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="323"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="737"/>
        <source>Console</source>
        <translation>컴퓨터 관리</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="325"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="773"/>
        <source>Color quality</source>
        <translation>색깔질감</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="326"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="774"/>
        <source>Self-adaption</source>
        <translation>자동조정</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="327"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="775"/>
        <source>True color (24bit)</source>
        <translation>진채（24비트）</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="328"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="776"/>
        <source>High color (16bit)</source>
        <translation>강렬한색（16비트）</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="329"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="777"/>
        <source>256 multicolor (8bit)</source>
        <translation>256색（8비트）</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="330"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="778"/>
        <source>256-color grayscale (8bit)</source>
        <translation>256회색톤（8비트）</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="331"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="779"/>
        <source>16-color grayscale (4bit)</source>
        <translation>16회색톤（4비트）</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="332"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="780"/>
        <source>True color (24bit lossy compression)</source>
        <translation>진채색(24비트 손상된 압축파일)</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="333"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="781"/>
        <source>Video</source>
        <translation>동영상</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="335"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="832"/>
        <source>Resolution</source>
        <translation>해상도</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="336"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="833"/>
        <source>Auto adjust</source>
        <translation>자동조정</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="338"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="846"/>
        <source>Enable screen whiteboard</source>
        <translation>스크린 화이트 보드를 사용</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="339"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="847"/>
        <source>Sync clipboard</source>
        <translation>동기화 클립 보드</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="342"/>
        <source>Console select</source>
        <translation>사용자 전환</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="930"/>
        <source>user</source>
        <translation>사용자</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="341"/>
        <source>Screen select</source>
        <translation>스크린 선택</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="343"/>
        <source>Blank screen</source>
        <translation>블랙스크린</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="344"/>
        <source>Mode select</source>
        <translation>모드 선택</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="345"/>
        <source>Shortcut</source>
        <translation>단축키</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="346"/>
        <source>Color settings</source>
        <translation>색채설정</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="347"/>
        <source>View settings</source>
        <translation>투시 설정</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="348"/>
        <source>Accessibility</source>
        <translation>보조기능</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="349"/>
        <source>Full-screen</source>
        <translation>전체스크린</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.cpp" line="350"/>
        <source>Sound</source>
        <translation>소리</translation>
    </message>
    <message>
        <source>Enable black screen model2</source>
        <translation type="obsolete">han</translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="80"/>
        <source>全屏</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="134"/>
        <source>色彩设置</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="188"/>
        <source>视图设置</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="242"/>
        <source>快捷键</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="296"/>
        <source>黑屏</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="351"/>
        <source>辅助功能</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="405"/>
        <source>模式选择</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="463"/>
        <source>声音</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="517"/>
        <location filename="../plugin/OrayDesktopControl/remotedesktopbottombar.ui" line="575"/>
        <source>屏幕选择</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>RemoteWakeUp</name>
    <message>
        <location filename="qml/RemoteWakeUp.qml" line="13"/>
        <location filename="qml/RemoteWakeUp.qml" line="278"/>
        <source>Unknown error!</source>
        <translation>오류불명！</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUp.qml" line="116"/>
        <source>Wake up time out</source>
        <translation>부트 명령은 클라이언트가 온라인상에서 검출되지 않고, 발행되었는지</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUp.qml" line="130"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUp.qml" line="282"/>
        <source>This host is not bound or wakeup service has expired</source>
        <translation>전환 서비스가 만료되었거나 사용할 수없는 권한을 부여한</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUp.qml" line="285"/>
        <source>Wake-up data does not exist</source>
        <translation>웨이크업 데이터가 존재하지 않습니다</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUp.qml" line="288"/>
        <source>Wake up failed</source>
        <translation>부팅실패</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUp.qml" line="291"/>
        <source>Wake-up password can not be empty!</source>
        <translation>부팅 비밀번호 빈 칸으로 남겨둘 수 없습니다!</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUp.qml" line="294"/>
        <source>Wake-up password wrong!</source>
        <translation>부팅 비밀번호 오류!</translation>
    </message>
</context>
<context>
    <name>RemoteWakeUpTip</name>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="23"/>
        <source>This camera is not online</source>
        <translation>이 카메라 안 -</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="24"/>
        <source>Please try again after login this camera</source>
        <translation>당 신의 주 세요. 重试 온라인 뒤 카메라 로그인</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="60"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="137"/>
        <source>This host does not support remote boot</source>
        <translation>이 호스트는 원격 부팅을 지원하지 않습니다</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="168"/>
        <source>Install </source>
        <translation>설치</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="176"/>
        <source>Sunlogin wakeup stick</source>
        <translation>해바라기 원격 부팅 스틱</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="196"/>
        <source> use this feature</source>
        <translation>이 기능을 사용 후</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="208"/>
        <source>Qualcomm co-brands such as Lenovo, Gigabyte models device supports remote boot sunlogin</source>
        <translation>Lenovo와 GIGABYTE와 같은 Qualcomm합작 브랜드와 같은 일부 모델은 해바라기 원격부팅을 지원합니다</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="232"/>
        <source>Detailed Model</source>
        <translation>자세한 모델</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeUpTip.qml" line="251"/>
        <source> Please consult your device manufacturer</source>
        <translation> 은 설비 제조업자와 문의해주세요</translation>
    </message>
</context>
<context>
    <name>RemoteWakeupPasswordView</name>
    <message>
        <source>Host login</source>
        <translation type="obsolete">호스트 로그온</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeupPasswordView.qml" line="29"/>
        <location filename="qml/RemoteWakeupPasswordView.qml" line="77"/>
        <source>Wake-up password</source>
        <translation>부팅 비밀번호</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeupPasswordView.qml" line="30"/>
        <location filename="qml/RemoteWakeupPasswordView.qml" line="82"/>
        <source>Remember</source>
        <translation>저를 기억</translation>
    </message>
    <message>
        <location filename="qml/RemoteWakeupPasswordView.qml" line="60"/>
        <source>Remote wake</source>
        <translation>원격부팅</translation>
    </message>
</context>
<context>
    <name>ScreenWall</name>
    <message>
        <source>Video wall</source>
        <translation type="obsolete">스크린 검사</translation>
    </message>
    <message>
        <location filename="qml/ScreenWall.qml" line="37"/>
        <location filename="qml/ScreenWall.qml" line="729"/>
        <location filename="qml/ScreenWall.qml" line="755"/>
        <source>Screen wall</source>
        <translation>屏幕墙</translation>
    </message>
</context>
<context>
    <name>ScreenWallSetting</name>
    <message>
        <location filename="qml/ScreenWallSetting.qml" line="77"/>
        <location filename="qml/ScreenWallSetting.qml" line="95"/>
        <source>View setting</source>
        <translation>전망 설립</translation>
    </message>
    <message>
        <location filename="qml/ScreenWallSetting.qml" line="121"/>
        <source>refresh frequency : </source>
        <translation>혁명 주파수:</translation>
    </message>
    <message>
        <location filename="qml/ScreenWallSetting.qml" line="160"/>
        <source>5-60s</source>
        <translation>5-60s</translation>
    </message>
    <message>
        <location filename="qml/ScreenWallSetting.qml" line="169"/>
        <source>screen size : </source>
        <translation>스크린 크기:</translation>
    </message>
    <message>
        <location filename="qml/ScreenWallSetting.qml" line="216"/>
        <source>ok</source>
        <translation>결심</translation>
    </message>
    <message>
        <location filename="qml/ScreenWallSetting.qml" line="230"/>
        <source>cancel</source>
        <translation>취소</translation>
    </message>
</context>
<context>
    <name>ScreenWallSprite</name>
    <message>
        <source>登陆</source>
        <translation type="obsolete">양륙</translation>
    </message>
    <message>
        <source>离线</source>
        <translation type="obsolete">따로 잇기</translation>
    </message>
    <message>
        <location filename="qml/ScreenWallSprite.qml" line="311"/>
        <source>Login</source>
        <translation>로그인</translation>
    </message>
    <message>
        <location filename="qml/ScreenWallSprite.qml" line="319"/>
        <source>Offline</source>
        <translation>호스트 오프라인</translation>
    </message>
</context>
<context>
    <name>SelectedListView</name>
    <message>
        <source>Add host</source>
        <translation type="obsolete">데스크톱 추가</translation>
    </message>
    <message>
        <location filename="qml/SelectedListView.qml" line="338"/>
        <source>free</source>
        <translation>영구</translation>
    </message>
    <message>
        <location filename="qml/SelectedListView.qml" line="381"/>
        <location filename="qml/SelectedListView.qml" line="451"/>
        <location filename="qml/SelectedListView.qml" line="482"/>
        <location filename="qml/SelectedListView.qml" line="511"/>
        <source>norm</source>
        <translation>보통</translation>
    </message>
    <message>
        <location filename="qml/SelectedListView.qml" line="459"/>
        <location filename="qml/SelectedListView.qml" line="489"/>
        <location filename="qml/SelectedListView.qml" line="518"/>
        <location filename="qml/SelectedListView.qml" line="534"/>
        <source>genl</source>
        <translation>추가</translation>
    </message>
    <message>
        <location filename="qml/SelectedListView.qml" line="550"/>
        <source>Permanent authorization</source>
        <translation>퍼머넌트 라이센스</translation>
    </message>
</context>
<context>
    <name>SendFileDlg</name>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.ui" line="14"/>
        <source>Form</source>
        <translation>파일 전송</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.ui" line="39"/>
        <source>发送文件：</source>
        <translation>파일 보내기：</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.ui" line="52"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.ui" line="78"/>
        <source>XXX</source>
        <translation>XXX</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.ui" line="65"/>
        <source>至</source>
        <translation>에</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.ui" line="91"/>
        <source>速度：</source>
        <translation>속도 :</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.ui" line="104"/>
        <source>取消</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="231"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="235"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="319"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="323"/>
        <source> to </source>
        <translation>에</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="234"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="322"/>
        <source>Send file:</source>
        <translation>파일 보내기：</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="242"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="256"/>
        <source>Remote client</source>
        <translation>고소당하다. 단</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="246"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="260"/>
        <source>Control client</source>
        <translation>마스터 끝</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="252"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="331"/>
        <source>Recive file:</source>
        <translation>수신 파일：</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="253"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="332"/>
        <source> frome </source>
        <translation>부터</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="284"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="339"/>
        <source>Speed:</source>
        <translation>속도 :</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="284"/>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="339"/>
        <source>left time:</source>
        <translation>남은 시간：</translation>
    </message>
</context>
<context>
    <name>SendFileShowThread</name>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="62"/>
        <source>Speed:</source>
        <translation>속도 :</translation>
    </message>
    <message>
        <location filename="../plugin/OrayChatClient/SendFileDlg.cpp" line="63"/>
        <source>left time:</source>
        <translation>남은 시간：</translation>
    </message>
</context>
<context>
    <name>SetCruiseDlg</name>
    <message>
        <location filename="../plugin/CameraPlayer/setcruisedlg.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/setcruisedlg.ui" line="163"/>
        <source>Cruise</source>
        <translation>크루즈</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/setcruisedlg.cpp" line="12"/>
        <source>H Cruise</source>
        <translation>크루즈 주위</translation>
    </message>
</context>
<context>
    <name>SetDirectionDlg</name>
    <message>
        <location filename="../plugin/CameraPlayer/setdirectiondlg.ui" line="26"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
<context>
    <name>SetPositionDlg</name>
    <message>
        <location filename="../plugin/CameraPlayer/setpositiondlg.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/setpositiondlg.ui" line="262"/>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
    <message>
        <source>我的位置巡航</source>
        <translation type="obsolete">내 위치 크루즈</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/setpositiondlg.cpp" line="32"/>
        <source>cruise</source>
        <translation>내 위치 크루즈</translation>
    </message>
</context>
<context>
    <name>SimpleTextEdit</name>
    <message>
        <location filename="qml/SimpleTextEdit.qml" line="31"/>
        <location filename="qml/SimpleTextEdit.qml" line="92"/>
        <source>Please input hosts name(You can add up to 5 hosts once)Please input Enter or Semicolon between hosts name.</source>
        <translation>사용자설정 호스트 명칭.</translation>
    </message>
</context>
<context>
    <name>Toolbar</name>
    <message>
        <location filename="../plugin/CameraPlayer/toolbar.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../plugin/CameraPlayer/toolbar.ui" line="259"/>
        <source>00:00:00</source>
        <translation>5-60s {00:00:00?}</translation>
    </message>
</context>
<context>
    <name>UnLockWindow</name>
    <message>
        <source>Sunlogin Remote Control 6.0 is locked</source>
        <translation type="obsolete">해바라기 6.0 클라이언트 잠금상태</translation>
    </message>
    <message>
        <location filename="qml/UnLockWindow.qml" line="11"/>
        <source>Unknown error!</source>
        <translation>오류불명！</translation>
    </message>
    <message>
        <location filename="qml/UnLockWindow.qml" line="109"/>
        <location filename="qml/UnLockWindow.qml" line="128"/>
        <source>Sunlogin ControlClient is locked</source>
        <translation>해바라기 리모트 주체가 잠금상태입니다</translation>
    </message>
    <message>
        <location filename="qml/UnLockWindow.qml" line="32"/>
        <source>Wrong password, please re-enter</source>
        <translation>비밀번호 오류,다시 입력해주세요</translation>
    </message>
    <message>
        <location filename="qml/UnLockWindow.qml" line="213"/>
        <source>Please enter the unlock password</source>
        <translation>비밀번호를 입력하세요</translation>
    </message>
</context>
<context>
    <name>UserInfoBallon</name>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="42"/>
        <location filename="qml/UserInfoBallon.qml" line="67"/>
        <source>Free Service</source>
        <translation>무료</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="46"/>
        <source>Pro Service</source>
        <translation>전문</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="50"/>
        <source>Enterprise Service</source>
        <translation>비즈니스</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="64"/>
        <source>used/total:</source>
        <translation>사용 / 호스트 :</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="65"/>
        <source>expire date:</source>
        <translation>유효 기간 :</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="73"/>
        <source>used amount: </source>
        <translation>중고 호스트 :</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="76"/>
        <source>upgrade</source>
        <translation>업그레이드</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="84"/>
        <location filename="qml/UserInfoBallon.qml" line="132"/>
        <source>used/total: </source>
        <translation>사용 / 호스트 :</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="87"/>
        <location filename="qml/UserInfoBallon.qml" line="149"/>
        <source>renew/upgrade</source>
        <translation>갱신 / 업그레이드 해주세요 </translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="123"/>
        <source>use level</source>
        <translation>사용 기준</translation>
    </message>
    <message>
        <location filename="qml/UserInfoBallon.qml" line="141"/>
        <source>expire date: </source>
        <translation>유효 기간 :</translation>
    </message>
</context>
<context>
    <name>WakeUpStickInfoWindow</name>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="99"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="117"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="129"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="141"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="230"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="455"/>
        <source>OK</source>
        <translation>결정</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="106"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="124"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="136"/>
        <source>Loading...</source>
        <translation>인식중…</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="152"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="228"/>
        <source>Check for update</source>
        <translation>업데이트 검색</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="199"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="221"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="246"/>
        <source>Wakeup stick information</source>
        <translation>부팅스틱속성</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="222"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="331"/>
        <source>Common</source>
        <translation>일반</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="89"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="223"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="352"/>
        <source>Authorized host</source>
        <translation>호스트 권한</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="364"/>
        <source>Authorized host tab</source>
        <translation>호스트 권한 tab </translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="224"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="376"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="388"/>
        <source>IP settings</source>
        <translation>IP설비</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="87"/>
        <source>Host manager</source>
        <translation>호스트 관리</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="115"/>
        <source>Refresh</source>
        <translation>새로 고침</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="225"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="405"/>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="420"/>
        <source>DDNS settings</source>
        <translation>땅콩 껍질 DDNS</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="226"/>
        <source>Online update</source>
        <translation>업데이트</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="476"/>
        <source>Saving...</source>
        <translation>저장중...</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindow.qml" line="515"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
</context>
<context>
    <name>WakeUpStickInfoWindowPage1</name>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="41"/>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="74"/>
        <source>Name:</source>
        <translation>이름:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="42"/>
        <source>Account:</source>
        <translation>소속계정: </translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="43"/>
        <source>Date of production:</source>
        <translation>시장출시일자:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="44"/>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="101"/>
        <source>MAC address:</source>
        <translation>MAC주소:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="45"/>
        <source>Serial number:</source>
        <translation>순서번호:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="46"/>
        <source>Bound hosts count:</source>
        <translation>엑세스한 기기수:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="47"/>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="149"/>
        <source>Assignment wakeup stick</source>
        <translation>부팅스틱 양도</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="114"/>
        <source>Serviceexpiredate:</source>
        <translation>전환 서비스 기한:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage1.qml" line="214"/>
        <source>Renew</source>
        <translation>갱신</translation>
    </message>
</context>
<context>
    <name>WakeUpStickInfoWindowPage2</name>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="78"/>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="196"/>
        <source>Authorized hosts</source>
        <translation>크레딧한 호스트</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="195"/>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="527"/>
        <source>Please select the host you want to bind</source>
        <translation>엑세스 필요한 호스트 선택</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="231"/>
        <source>Free Service</source>
        <translation>무료</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="235"/>
        <source>Pro Service</source>
        <translation>전문</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="239"/>
        <source>Enterprise Service</source>
        <translation>비즈니스</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="279"/>
        <source>Bind Failed</source>
        <translation>추가 실패</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="292"/>
        <source>Lack of authorization, please add authorization</source>
        <translation>권한 부여의 부족, 권한 부여를 추가</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="359"/>
        <source>Wakeup stick and authorized hosts should be at the same lan</source>
        <translation>부팅스틱 및 인증 된 호스트 같은 LAN 있어야 합니다</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="378"/>
        <source>General authorization expired, please </source>
        <translation>일반 라이센스 만료 했습니다,</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="384"/>
        <source>; permanent authorization is available</source>
        <translation>. 퍼머넌트 라이센스 여전히 사용</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="397"/>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="490"/>
        <source>renew</source>
        <translation>했습니다. 갱신 / 업그레이드 해주세요</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="431"/>
        <source>General authorization will be expired in </source>
        <translation>일반 라이센스 </translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="437"/>
        <source>, please </source>
        <translation>만료 합니다,</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="450"/>
        <source>renew/upgrade</source>
        <translation>갱신 / 업그레이드 해주세요 </translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="484"/>
        <source>Sunlogin </source>
        <translation>해바라기</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="484"/>
        <source> will be expired in </source>
        <translation>만료</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="484"/>
        <source>,please </source>
        <translation>，제발</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2.qml" line="562"/>
        <source>Add Authorization</source>
        <translation>권한 추가</translation>
    </message>
</context>
<context>
    <name>WakeUpStickInfoWindowPage2_new</name>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2_new.qml" line="14"/>
        <source>Refresh...</source>
        <translation>새로 고침 ...</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2_new.qml" line="177"/>
        <source>Wakeup stick and authorized hosts should be at the same lan</source>
        <translation>컴퓨터 및로드를 켜 동일한 LAN에 접속하는</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2_new.qml" line="208"/>
        <source>hostname</source>
        <translation>호스트 이름</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2_new.qml" line="216"/>
        <source>action</source>
        <translation>운영</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2_new.qml" line="262"/>
        <source>Wakeup</source>
        <translation>신병</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2_new.qml" line="324"/>
        <source>Host not found </source>
        <translation>호스트를 찾을 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage2_new.qml" line="333"/>
        <source>(wakeup stick can automatically discover the LAN host and complete the binding)</source>
        <translation>(부팅 스틱이 자동으로 LAN 호스트를 발견하고 온라인 바인딩을 완료)</translation>
    </message>
    <message>
        <source>Did not find the relevant host , returns </source>
        <translation type="obsolete">호스트를 찾을 수 없습니다 (전원 표시 줄이 자동으로 LAN 호스트를 발견하고 온라인 바인딩을 완료 할 수 있습니다)</translation>
    </message>
    <message>
        <source>all host list</source>
        <translation type="obsolete">전체 호스트 목록</translation>
    </message>
</context>
<context>
    <name>WakeUpStickInfoWindowPage3</name>
    <message>
        <source>IP address can not be empty</source>
        <translation type="obsolete">IP주소는 빈 칸이 될 수 없습니다</translation>
    </message>
    <message>
        <source>Missing subnet mask.</source>
        <translation type="obsolete">부분망 마스크를 추가해주세요</translation>
    </message>
    <message>
        <source>Combination of IP address and subnet mask is invalid</source>
        <translation type="obsolete">IP주소와 부분망 마스크가 유효하지 않습니다</translation>
    </message>
    <message>
        <source>Subnet mask format is incorrect</source>
        <translation type="obsolete">부분망 마스크 격식이 맞지 않습니다</translation>
    </message>
    <message>
        <source>The default gateway is incorrect</source>
        <translation type="obsolete">기본 게이트웨이 격식이 맞지 않습니다</translation>
    </message>
    <message>
        <source>Secondary DNS cannot be the same as the preferred DNS</source>
        <translation type="obsolete">예비DNS는 우선DNS와 같을 수 없습니다</translation>
    </message>
    <message>
        <source>Secondary DNS format is not correct</source>
        <translation type="obsolete">우선DNS격식이 맞지 않습니다</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="40"/>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="315"/>
        <source>Fail to set stick ip addr.</source>
        <translation>정전 스틱 IP 설정.</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="83"/>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="307"/>
        <source>Fail to get stick ip addr.</source>
        <translation>IP 정보 실패 부팅 스틱을 가져옵니다.</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="174"/>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="368"/>
        <source>Wake-up stick isn&apos;t in current Lan, Modifing stick may be takn offline</source>
        <translation>아니 현재의 LAN 부팅 스틱, IP가 온라인 상태가 아닌 부팅 스틱으로 이어질 수 변경주의를 기울여야하십시오</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="184"/>
        <source>Old version Wake-up stick isn&apos;t in current Lan</source>
        <translation>이 막대는 LAN 부팅에서 현재 사용하지 않는, IP를 설정할 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="210"/>
        <source>Wake-up stick is offline couldn&apos;t be modified.</source>
        <translation>부팅 스틱하면 온라인 상태가 아닌, 당신은 IP를 설정할 수 없습니다.</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="239"/>
        <source>Input can not be empty</source>
        <translation>IP를 입력하고 다른 정보는 비워 둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="246"/>
        <source>Please input correct ip and subnet mask addr</source>
        <translation>올바른 IP와 서브넷 마스크를 입력하십시오</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="281"/>
        <source>Obtain an IP address automatically</source>
        <translation>IP주소 자동설비</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="282"/>
        <source>Use the following IP address</source>
        <translation>아래 IP주소 사용</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="283"/>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="465"/>
        <source>IP address:</source>
        <translation>IP주소:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="284"/>
        <source>Subnet mask:</source>
        <translation>인터넷 마스크:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="285"/>
        <source>Default gateway:</source>
        <translation>기본 게이트웨이:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="286"/>
        <source>Obtain DNS server address automatically</source>
        <translation>DNS서버주소 자동획득</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="287"/>
        <source>Use the following DNS server addresses</source>
        <translation>아래 DNS서버주소</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="288"/>
        <source>Preferred:</source>
        <translation>첫 선택:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="289"/>
        <source>Standby:</source>
        <translation>예비용:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="381"/>
        <source>Self state checking</source>
        <translation>부트 프로세스를 고집하지 않는 온라인자가 테스트</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="422"/>
        <source>DHCP</source>
        <translation>DHCP</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="445"/>
        <source>Static IP</source>
        <translation>고정 IP를 사용</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="501"/>
        <source>Subnet Mask:</source>
        <translation>서브넷 마스크:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="537"/>
        <source>gateway:</source>
        <translation>게이트웨이 :</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage3.qml" line="570"/>
        <source>DNS:</source>
        <translation>DNS:</translation>
    </message>
</context>
<context>
    <name>WakeUpStickInfoWindowPage4</name>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="97"/>
        <source>Incorrect username or password</source>
        <translation>아이디 혹은 비밀번호 오류</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="117"/>
        <source>DDNS account can not be empty</source>
        <translation>DDNS의 계정설정은 빈 칸으로 남겨둘 수 없습니다</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="79"/>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="130"/>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="172"/>
        <source>Please active the service of PeanutHull in the corresponding account management interface</source>
        <translation>해당 계정에서 “땅콩껍질관리서비스”를 활성화시키십시오.</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="74"/>
        <source>Stick is offline, DDNS doesn&apos;t work,more info. </source>
        <translation>부팅 스틱하면 온라인 상태가 아닌, 당신은 땅콩 껍질 DDNS를 사용할 수 없습니다。</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="131"/>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="219"/>
        <source>Enable DDNS</source>
        <translation>DDNS 실행</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="132"/>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="236"/>
        <source>Enable PeanutHull DDNS belonged to this account</source>
        <translation>해당계정 DDNS땅콩껍질실행</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="133"/>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="257"/>
        <source>Enable PeanutHull DDNS belonged to designated account</source>
        <translation>기타 DDNS땅콩껍질실행</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="134"/>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="276"/>
        <source>Username:</source>
        <translation>아이디:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="135"/>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="314"/>
        <source>Password:</source>
        <translation>비밀번호:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="136"/>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="353"/>
        <source>Service level:</source>
        <translation>서비스 단계:</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage4.qml" line="185"/>
        <source>http://hsk.oray.com/</source>
        <translation>땅콩 껍질 알아보기</translation>
    </message>
</context>
<context>
    <name>WakeUpStickInfoWindowPage5</name>
    <message>
        <source>Is the latest version</source>
        <translation type="obsolete">이미 최신판입니다</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage5.qml" line="45"/>
        <source>Is the latest version, need not update</source>
        <translation>이미 최신판이므로 업데이트를 할 필요가 없습니다</translation>
    </message>
    <message>
        <source>Updating</source>
        <translation type="obsolete">현재 업데이트중</translation>
    </message>
    <message>
        <location filename="qml/WakeUpStickInfoWindowPage5.qml" line="89"/>
        <location filename="qml/WakeUpStickInfoWindowPage5.qml" line="109"/>
        <source>The current version of wakeup stick is:</source>
        <translation>이 부팅스틱 현재번호:</translation>
    </message>
    <message>
        <source>The latest version of wakeup stick is:</source>
        <translation type="obsolete">이 부팅스틱 최신판번호:</translation>
    </message>
</context>
<context>
    <name>WakeupStickNoInLanTip</name>
    <message>
        <location filename="qml/WakeupStickNoInLanTip.qml" line="62"/>
        <source>Control client and wake-up stick need to be in the same LAN,</source>
        <translation>동일한 LAN에있는 제어 및 전원로드</translation>
    </message>
    <message>
        <location filename="qml/WakeupStickNoInLanTip.qml" line="74"/>
        <source>See </source>
        <translation>체크 아웃</translation>
    </message>
    <message>
        <location filename="qml/WakeupStickNoInLanTip.qml" line="86"/>
        <source>how to install a wake-up stick into a LAN</source>
        <translation>현재 LAN 부팅 스틱을 초기화하는 방법</translation>
    </message>
    <message>
        <location filename="qml/WakeupStickNoInLanTip.qml" line="113"/>
        <source>Bind a wake-up stick to your code </source>
        <translation>벨로우즈 바인딩</translation>
    </message>
    <message>
        <location filename="qml/WakeupStickNoInLanTip.qml" line="125"/>
        <source>use account management</source>
        <translation>사용자 계정 관리</translation>
    </message>
    <message>
        <location filename="qml/WakeupStickNoInLanTip.qml" line="153"/>
        <source>OK</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>WakeupStickOfflineTip</name>
    <message>
        <location filename="qml/WakeupStickOfflineTip.qml" line="66"/>
        <source>Sunlogin Remote Control wakeup stick is not online, please make sure it is installed correctly?</source>
        <translation>부트 스틱이 온라인이 아닌 여부 설치를 확인?</translation>
    </message>
    <message>
        <location filename="qml/WakeupStickOfflineTip.qml" line="78"/>
        <source>For details</source>
        <translation>상세히 보기</translation>
    </message>
    <message>
        <location filename="qml/WakeupStickOfflineTip.qml" line="90"/>
        <source>How to install wakeup stick</source>
        <translation>부팅스틱을 어떻게 설치하나요</translation>
    </message>
    <message>
        <location filename="qml/WakeupStickOfflineTip.qml" line="118"/>
        <source>OK</source>
        <translation>확인</translation>
    </message>
</context>
<context>
    <name>WindowsPluginConnect</name>
    <message>
        <location filename="windowspluginconnect.cpp" line="16"/>
        <source>Loading...</source>
        <translation>서명...</translation>
    </message>
    <message>
        <location filename="windowspluginconnect.cpp" line="182"/>
        <source>P2P connection is being established</source>
        <translation>P2P연결 생성중 </translation>
    </message>
    <message>
        <location filename="windowspluginconnect.cpp" line="186"/>
        <source>Is requesting forwarding</source>
        <translation>발송요청중</translation>
    </message>
    <message>
        <location filename="windowspluginconnect.cpp" line="190"/>
        <source>Loginning</source>
        <translation>로그인중</translation>
    </message>
    <message>
        <location filename="windowspluginconnect.cpp" line="196"/>
        <source>Connection is interrupted</source>
        <translation>연결이 중단됩니다</translation>
    </message>
    <message>
        <location filename="windowspluginconnect.cpp" line="205"/>
        <source>Connection completed</source>
        <translation>연결됨</translation>
    </message>
    <message>
        <location filename="windowspluginconnect.ui" line="20"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="windowspluginconnect.ui" line="35"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="windowspluginconnect.ui" line="55"/>
        <source>正在连接...</source>
        <translation></translation>
    </message>
</context>
</TS>
